# B15 Student Progress Dashboard (Netlify)

- `public/index.html` : kerangka halaman (tanpa data santri) + layar kode akses.
- `netlify/functions/db.mjs` : server kecil (Netlify Functions + Blobs). Menyimpan data dan baru mengirim kode aplikasi
  setelah kode akses benar.
- Kode akses = variabel lingkungan `ACCESS_CODE` (scope: Functions). Ganti nilainya lalu deploy ulang untuk mengubah kode.
- Server menolak semua permintaan kalau `ACCESS_CODE` belum diatur.
