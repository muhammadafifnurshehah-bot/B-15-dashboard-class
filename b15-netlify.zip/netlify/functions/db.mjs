// node_modules/@netlify/runtime-utils/dist/main.js
var getString = (input) => typeof input === "string" ? input : JSON.stringify(input);
var base64Decode = globalThis.Buffer ? (input) => Buffer.from(input, "base64").toString() : (input) => atob(input);
var base64Encode = globalThis.Buffer ? (input) => Buffer.from(getString(input)).toString("base64") : (input) => btoa(getString(input));
var getEnvironment = () => {
  const { Deno, Netlify: Netlify2, process } = globalThis;
  return Netlify2?.env ?? Deno?.env ?? {
    delete: (key) => delete process?.env[key],
    get: (key) => process?.env[key],
    has: (key) => Boolean(process?.env[key]),
    set: (key, value) => {
      if (process?.env) {
        process.env[key] = value;
      }
    },
    toObject: () => process?.env ?? {}
  };
};

// node_modules/@netlify/otel/dist/main.js
var GET_TRACER = "__netlify__getTracer";
var getTracer = (name, version) => {
  return globalThis[GET_TRACER]?.(name, version);
};
function withActiveSpan(tracer, name, optionsOrFn, contextOrFn, fn) {
  const func = typeof contextOrFn === "function" ? contextOrFn : typeof optionsOrFn === "function" ? optionsOrFn : fn;
  if (!func) {
    throw new Error("function to execute with active span is missing");
  }
  if (!tracer) {
    return func();
  }
  return tracer.withActiveSpan(name, optionsOrFn, contextOrFn, func);
}

// node_modules/@netlify/blobs/dist/chunk-SQCJ2S3G.js
var getEnvironmentContext = () => {
  const context = globalThis.netlifyBlobsContext || getEnvironment().get("NETLIFY_BLOBS_CONTEXT");
  if (typeof context !== "string" || !context) {
    return {};
  }
  const data = base64Decode(context);
  try {
    return JSON.parse(data);
  } catch {
  }
  return {};
};
var MissingBlobsEnvironmentError = class extends Error {
  constructor(requiredProperties) {
    super(
      `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
        ", "
      )}`
    );
    this.name = "MissingBlobsEnvironmentError";
  }
};
var BASE64_PREFIX = "b64;";
var METADATA_HEADER_INTERNAL = "x-amz-meta-user";
var METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
var METADATA_MAX_SIZE = 2 * 1024;
var encodeMetadata = (metadata) => {
  if (!metadata) {
    return null;
  }
  const encodedObject = base64Encode(JSON.stringify(metadata));
  const payload = `b64;${encodedObject}`;
  if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
    throw new Error("Metadata object exceeds the maximum size");
  }
  return payload;
};
var decodeMetadata = (header) => {
  if (!header?.startsWith(BASE64_PREFIX)) {
    return {};
  }
  const encodedData = header.slice(BASE64_PREFIX.length);
  const decodedData = base64Decode(encodedData);
  const metadata = JSON.parse(decodedData);
  return metadata;
};
var getMetadataFromResponse = (response) => {
  if (!response.headers) {
    return {};
  }
  const value = response.headers.get(METADATA_HEADER_EXTERNAL) || response.headers.get(METADATA_HEADER_INTERNAL);
  try {
    return decodeMetadata(value);
  } catch {
    throw new Error(
      "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
    );
  }
};
var NF_ERROR = "x-nf-error";
var NF_REQUEST_ID = "x-nf-request-id";
var DEPLOY_STORE_PREFIX = "deploy:";
var SITE_STORE_PREFIX = "site:";
var isDeniedWrite = (res, { method, storeName }) => (res.status === 401 || res.status === 403) && (method === "put" || method === "delete") && storeName !== void 0 && !storeName.startsWith(DEPLOY_STORE_PREFIX);
var blobsErrorMessage = (res, context, responseBody) => {
  let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
  if (res.headers.has(NF_REQUEST_ID)) {
    details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
  }
  if (isDeniedWrite(res, context)) {
    const storeName = context.storeName?.startsWith(SITE_STORE_PREFIX) ? context.storeName.slice(SITE_STORE_PREFIX.length) : context.storeName;
    const summary = `Netlify Blobs could not write to store '${storeName}' (${details}).`;
    if (context.edgeAccess) {
      return summary;
    }
    return `${summary} Builds and build plugins can only write to deploy-specific stores: use 'getDeployStore' instead of 'getStore', or pass a 'token' with write access to the store. If this code is not running in a build, check that the token and site ID are valid. See https://docs.netlify.com/build/data-and-storage/netlify-blobs/#deploy-specific-stores`;
  }
  let message = `Netlify Blobs has generated an internal error (${details})`;
  if (!res.headers.get(NF_ERROR) && responseBody) {
    message += `: ${responseBody}`;
  }
  return message;
};
var BlobsInternalError = class extends Error {
  constructor(res, context = {}, responseBody) {
    super(blobsErrorMessage(res, context, responseBody));
    this.name = "BlobsInternalError";
    this.status = res.status;
    this.responseBody = responseBody;
  }
};
var createBlobsInternalError = async (res, context = {}) => {
  const responseBody = await res.clone().text().catch(() => void 0);
  return new BlobsInternalError(res, context, responseBody);
};
var discardBody = async (res) => {
  await res.body?.cancel().catch(() => {
  });
};
var collectIterator = async (iterator) => {
  const result = [];
  for await (const item of iterator) {
    result.push(item);
  }
  return result;
};
function withSpan(span, name, fn) {
  if (span) return fn(span);
  return withActiveSpan(getTracer(), name, (span2) => {
    return fn(span2);
  });
}
var BlobsConsistencyError = class extends Error {
  constructor() {
    super(
      `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
    );
    this.name = "BlobsConsistencyError";
  }
};
var REGION_AUTO = "auto";
var regions = {
  "us-east-1": true,
  "us-east-2": true,
  "eu-central-1": true,
  "ap-southeast-1": true,
  "ap-southeast-2": true
};
var isValidRegion = (input) => Object.keys(regions).includes(input);
var InvalidBlobsRegionError = class extends Error {
  constructor(region) {
    super(
      `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
    );
    this.name = "InvalidBlobsRegionError";
  }
};
var DEFAULT_RETRY_DELAY = getEnvironment().get("NODE_ENV") === "test" ? 1 : 5e3;
var MIN_RETRY_DELAY = 1e3;
var MAX_RETRY = 5;
var RATE_LIMIT_HEADER = "X-RateLimit-Reset";
var fetchAndRetry = async (fetch, url, options, attemptsLeft = MAX_RETRY, getRetryUrl) => {
  try {
    const res = await fetch(url, options);
    const isRetryable = res.status === 429 || res.status >= 500 || getRetryUrl !== void 0 && res.status === 403;
    if (attemptsLeft > 0 && isRetryable) {
      await discardBody(res);
      const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
      await sleep(delay);
      const retryUrl = getRetryUrl ? await getRetryUrl() : url;
      return fetchAndRetry(fetch, retryUrl, options, attemptsLeft - 1, getRetryUrl);
    }
    return res;
  } catch (error) {
    if (attemptsLeft === 0) {
      throw error;
    }
    const delay = getDelay();
    await sleep(delay);
    const retryUrl = getRetryUrl ? await getRetryUrl() : url;
    return fetchAndRetry(fetch, retryUrl, options, attemptsLeft - 1, getRetryUrl);
  }
};
var getDelay = (rateLimitReset) => {
  if (!rateLimitReset) {
    return DEFAULT_RETRY_DELAY;
  }
  return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
};
var sleep = (ms) => new Promise((resolve) => {
  setTimeout(resolve, ms);
});
var SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
var Client = class {
  /**
   * Whether requests reach Blobs through the edge rather than the API. Only
   * runtime environments are given an edge URL.
   */
  get edgeAccess() {
    return this.edgeURL !== void 0;
  }
  constructor({ apiURL, consistency, edgeURL, fetch, region, siteID, token, uncachedEdgeURL }) {
    this.apiURL = apiURL;
    this.consistency = consistency ?? "eventual";
    this.edgeURL = edgeURL;
    this.fetch = fetch ?? globalThis.fetch;
    this.region = region;
    this.siteID = siteID;
    this.token = token;
    this.uncachedEdgeURL = uncachedEdgeURL;
    if (!this.fetch) {
      throw new Error(
        "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
      );
    }
  }
  async getFinalRequest({
    consistency: opConsistency,
    key,
    metadata,
    method,
    parameters = {},
    storeName
  }) {
    const encodedMetadata = encodeMetadata(metadata);
    const consistency = opConsistency ?? this.consistency;
    let urlPath = `/${this.siteID}`;
    if (storeName) {
      urlPath += `/${storeName}`;
    }
    if (key) {
      urlPath += `/${key}`;
    }
    if (this.edgeURL) {
      if (consistency === "strong" && !this.uncachedEdgeURL) {
        throw new BlobsConsistencyError();
      }
      const headers = {
        authorization: `Bearer ${this.token}`
      };
      if (encodedMetadata) {
        headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
      }
      if (this.region) {
        urlPath = `/region:${this.region}${urlPath}`;
      }
      const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
      for (const key2 in parameters) {
        url2.searchParams.set(key2, parameters[key2]);
      }
      return {
        headers,
        url: url2.toString()
      };
    }
    const apiHeaders = { authorization: `Bearer ${this.token}` };
    const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
    for (const key2 in parameters) {
      url.searchParams.set(key2, parameters[key2]);
    }
    if (this.region) {
      url.searchParams.set("region", this.region);
    }
    if (storeName === void 0 || key === void 0) {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    if (encodedMetadata) {
      apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
    }
    if (method === "head" || method === "delete") {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    const res = await this.fetch(url.toString(), {
      headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
      method
    });
    if (res.status !== 200) {
      throw await createBlobsInternalError(res, { edgeAccess: this.edgeAccess, method, storeName });
    }
    const { url: signedURL } = await res.json();
    const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
    return {
      headers: userHeaders,
      url: signedURL
    };
  }
  async makeRequest({
    body,
    conditions = {},
    consistency,
    headers: extraHeaders,
    key,
    metadata,
    method,
    parameters,
    storeName
  }) {
    const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
      consistency,
      key,
      metadata,
      method,
      parameters,
      storeName
    });
    const headers = {
      ...baseHeaders,
      ...extraHeaders
    };
    if (method === "put") {
      headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
    }
    if ("onlyIfMatch" in conditions && conditions.onlyIfMatch) {
      headers["if-match"] = conditions.onlyIfMatch;
    } else if ("onlyIfNew" in conditions && conditions.onlyIfNew) {
      headers["if-none-match"] = "*";
    }
    const options = {
      body,
      headers,
      method
    };
    if (body instanceof ReadableStream) {
      options.duplex = "half";
    }
    const usesSignedUrl = !this.edgeURL && key !== void 0 && storeName !== void 0 && method !== "head" && method !== "delete";
    let getRetryUrl;
    if (usesSignedUrl) {
      getRetryUrl = async () => {
        const finalRequest = await this.getFinalRequest({ consistency, key, metadata, method, parameters, storeName });
        return finalRequest.url;
      };
    }
    return fetchAndRetry(this.fetch, url, options, void 0, getRetryUrl);
  }
};
var getClientOptions = (options, contextOverride) => {
  const context = contextOverride ?? getEnvironmentContext();
  const siteID = context.siteID ?? options.siteID;
  const token = context.token ?? options.token;
  if (!siteID || !token) {
    throw new MissingBlobsEnvironmentError(["siteID", "token"]);
  }
  if (options.region !== void 0 && !isValidRegion(options.region)) {
    throw new InvalidBlobsRegionError(options.region);
  }
  const clientOptions = {
    apiURL: context.apiURL ?? options.apiURL,
    consistency: options.consistency,
    edgeURL: context.edgeURL ?? options.edgeURL,
    fetch: options.fetch,
    region: options.region,
    siteID,
    token,
    uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
  };
  return clientOptions;
};

// node_modules/@netlify/blobs/dist/main.js
var LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
var STATUS_OK = 200;
var STATUS_PRE_CONDITION_FAILED = 412;
var STATUS_CONFLICT = 409;
var Store = class _Store {
  constructor(options) {
    this.client = options.client;
    if ("deployID" in options) {
      _Store.validateDeployID(options.deployID);
      let name = DEPLOY_STORE_PREFIX + options.deployID;
      if (options.name) {
        name += `:${options.name}`;
      }
      this.name = name;
    } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
      const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
      _Store.validateStoreName(storeName);
      this.name = storeName;
    } else {
      _Store.validateStoreName(options.name);
      this.name = SITE_STORE_PREFIX + options.name;
    }
  }
  async delete(key) {
    const res = await this.client.makeRequest({ key, method: "delete", storeName: this.name });
    await discardBody(res);
    if (![200, 204, 404].includes(res.status)) {
      throw new BlobsInternalError(res, {
        edgeAccess: this.client.edgeAccess,
        method: "delete",
        storeName: this.name
      });
    }
  }
  async deleteAll() {
    let totalDeletedBlobs = 0;
    let hasMore = true;
    while (hasMore) {
      const res = await this.client.makeRequest({ method: "delete", storeName: this.name });
      if (res.status !== 200) {
        await discardBody(res);
        throw new BlobsInternalError(res, {
          edgeAccess: this.client.edgeAccess,
          method: "delete",
          storeName: this.name
        });
      }
      const data = await res.json();
      if (typeof data.blobs_deleted !== "number") {
        throw new BlobsInternalError(res);
      }
      totalDeletedBlobs += data.blobs_deleted;
      hasMore = typeof data.has_more === "boolean" && data.has_more;
    }
    return {
      deletedBlobs: totalDeletedBlobs
    };
  }
  async get(key, options) {
    return withSpan(options?.span, "blobs.get", async (span) => {
      const { consistency, type } = options ?? {};
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.type": type,
        "blobs.method": "GET",
        "blobs.consistency": consistency
      });
      const res = await this.client.makeRequest({
        consistency,
        key,
        method: "get",
        storeName: this.name
      });
      span?.setAttributes({
        "blobs.response.body.size": res.headers.get("content-length") ?? void 0,
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        await discardBody(res);
        return null;
      }
      if (res.status !== 200) {
        await discardBody(res);
        throw new BlobsInternalError(res);
      }
      if (type === void 0 || type === "text") {
        return res.text();
      }
      if (type === "arrayBuffer") {
        return res.arrayBuffer();
      }
      if (type === "blob") {
        return res.blob();
      }
      if (type === "json") {
        return res.json();
      }
      if (type === "stream") {
        return res.body;
      }
      await discardBody(res);
      throw new BlobsInternalError(res);
    });
  }
  async getMetadata(key, options = {}) {
    return withSpan(options?.span, "blobs.getMetadata", async (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "HEAD",
        "blobs.consistency": options.consistency
      });
      const res = await this.client.makeRequest({
        consistency: options.consistency,
        key,
        method: "head",
        storeName: this.name
      });
      span?.setAttributes({
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        return null;
      }
      if (res.status !== 200 && res.status !== 304) {
        throw new BlobsInternalError(res);
      }
      const etag = res?.headers.get("etag") ?? void 0;
      const metadata = getMetadataFromResponse(res);
      const result = {
        etag,
        metadata
      };
      return result;
    });
  }
  async getWithMetadata(key, options) {
    return withSpan(options?.span, "blobs.getWithMetadata", async (span) => {
      const { consistency, etag: requestETag, type } = options ?? {};
      const headers = requestETag ? { "if-none-match": requestETag } : void 0;
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "GET",
        "blobs.consistency": options?.consistency,
        "blobs.type": type,
        "blobs.request.etag": requestETag
      });
      const res = await this.client.makeRequest({
        consistency,
        headers,
        key,
        method: "get",
        storeName: this.name
      });
      const responseETag = res?.headers.get("etag") ?? void 0;
      span?.setAttributes({
        "blobs.response.body.size": res.headers.get("content-length") ?? void 0,
        "blobs.response.etag": responseETag,
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        await discardBody(res);
        return null;
      }
      if (res.status !== 200 && res.status !== 304) {
        await discardBody(res);
        throw new BlobsInternalError(res);
      }
      const metadata = getMetadataFromResponse(res);
      const result = {
        etag: responseETag,
        metadata
      };
      if (res.status === 304 && requestETag) {
        return { data: null, ...result };
      }
      if (type === void 0 || type === "text") {
        return { data: await res.text(), ...result };
      }
      if (type === "arrayBuffer") {
        return { data: await res.arrayBuffer(), ...result };
      }
      if (type === "blob") {
        return { data: await res.blob(), ...result };
      }
      if (type === "json") {
        return { data: await res.json(), ...result };
      }
      if (type === "stream") {
        return { data: res.body, ...result };
      }
      await discardBody(res);
      throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
    });
  }
  list(options = {}) {
    return withSpan(options.span, "blobs.list", (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.method": "GET",
        "blobs.list.paginate": options.paginate ?? false
      });
      const iterator = this.getListIterator(options);
      if (options.paginate) {
        return iterator;
      }
      return collectIterator(iterator).then(
        (items) => items.reduce(
          (acc, item) => ({
            blobs: [...acc.blobs, ...item.blobs],
            directories: [...acc.directories, ...item.directories]
          }),
          { blobs: [], directories: [] }
        )
      );
    });
  }
  async set(key, data, options = {}) {
    return withSpan(options.span, "blobs.set", async (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "PUT",
        "blobs.data.size": typeof data == "string" ? data.length : data instanceof Blob ? data.size : data.byteLength,
        "blobs.data.type": typeof data == "string" ? "string" : data instanceof Blob ? "blob" : "arrayBuffer",
        "blobs.atomic": Boolean(options.onlyIfMatch ?? options.onlyIfNew)
      });
      _Store.validateKey(key);
      const conditions = _Store.getConditions(options);
      const res = await this.client.makeRequest({
        conditions,
        body: data,
        key,
        metadata: options.metadata,
        method: "put",
        storeName: this.name
      });
      const etag = res.headers.get("etag") ?? "";
      span?.setAttributes({
        "blobs.response.etag": etag,
        "blobs.response.status": res.status
      });
      if (conditions) {
        if (res.status === STATUS_PRE_CONDITION_FAILED || res.status === STATUS_CONFLICT) {
          await discardBody(res);
          return { modified: false };
        }
        if (res.ok) {
          await discardBody(res);
          return { etag, modified: true };
        }
        throw await createBlobsInternalError(res, {
          edgeAccess: this.client.edgeAccess,
          method: "put",
          storeName: this.name
        });
      }
      if (res.status === STATUS_OK) {
        await discardBody(res);
        return {
          etag,
          modified: true
        };
      }
      throw await createBlobsInternalError(res, {
        edgeAccess: this.client.edgeAccess,
        method: "put",
        storeName: this.name
      });
    });
  }
  async setJSON(key, data, options = {}) {
    return withSpan(options.span, "blobs.setJSON", async (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "PUT",
        "blobs.data.type": "json",
        "blobs.atomic": Boolean(options.onlyIfMatch ?? options.onlyIfNew)
      });
      _Store.validateKey(key);
      const conditions = _Store.getConditions(options);
      const payload = JSON.stringify(data);
      const headers = {
        "content-type": "application/json"
      };
      const res = await this.client.makeRequest({
        conditions,
        body: payload,
        headers,
        key,
        metadata: options.metadata,
        method: "put",
        storeName: this.name
      });
      const etag = res.headers.get("etag") ?? "";
      span?.setAttributes({
        "blobs.response.etag": etag,
        "blobs.response.status": res.status
      });
      if (conditions) {
        if (res.status === STATUS_PRE_CONDITION_FAILED || res.status === STATUS_CONFLICT) {
          await discardBody(res);
          return { modified: false };
        }
        if (res.ok) {
          await discardBody(res);
          return { etag, modified: true };
        }
        throw await createBlobsInternalError(res, {
          edgeAccess: this.client.edgeAccess,
          method: "put",
          storeName: this.name
        });
      }
      if (res.status === STATUS_OK) {
        await discardBody(res);
        return {
          etag,
          modified: true
        };
      }
      throw await createBlobsInternalError(res, {
        edgeAccess: this.client.edgeAccess,
        method: "put",
        storeName: this.name
      });
    });
  }
  static formatListResultBlob(result) {
    if (!result.key) {
      return null;
    }
    return {
      etag: result.etag,
      key: result.key
    };
  }
  static getConditions(options) {
    if ("onlyIfMatch" in options && "onlyIfNew" in options) {
      throw new Error(
        `The 'onlyIfMatch' and 'onlyIfNew' options are mutually exclusive. Using 'onlyIfMatch' will make the write succeed only if there is an entry for the key with the given content, while 'onlyIfNew' will make the write succeed only if there is no entry for the key.`
      );
    }
    if ("onlyIfMatch" in options && options.onlyIfMatch) {
      if (typeof options.onlyIfMatch !== "string") {
        throw new Error(`The 'onlyIfMatch' property expects a string representing an ETag.`);
      }
      return {
        onlyIfMatch: options.onlyIfMatch
      };
    }
    if ("onlyIfNew" in options && options.onlyIfNew) {
      if (typeof options.onlyIfNew !== "boolean") {
        throw new Error(
          `The 'onlyIfNew' property expects a boolean indicating whether the write should fail if an entry for the key already exists.`
        );
      }
      return {
        onlyIfNew: true
      };
    }
  }
  static validateKey(key) {
    if (key === "") {
      throw new Error("Blob key must not be empty.");
    }
    if (key.startsWith("/") || key.startsWith("%2F")) {
      throw new Error("Blob key must not start with forward slash (/).");
    }
    if (new TextEncoder().encode(key).length > 600) {
      throw new Error(
        "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
      );
    }
  }
  static validateDeployID(deployID) {
    if (!/^\w{1,24}$/.test(deployID)) {
      throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
    }
  }
  static validateStoreName(name) {
    if (name.includes("/") || name.includes("%2F")) {
      throw new Error("Store name must not contain forward slashes (/).");
    }
    if (new TextEncoder().encode(name).length > 64) {
      throw new Error(
        "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
      );
    }
  }
  getListIterator(options) {
    const { client, name: storeName } = this;
    const parameters = {};
    if (options?.prefix) {
      parameters.prefix = options.prefix;
    }
    if (options?.directories) {
      parameters.directories = "true";
    }
    return {
      [Symbol.asyncIterator]() {
        let currentCursor = null;
        let done = false;
        return {
          async next() {
            return withSpan(options?.span, "blobs.list.next", async (span) => {
              span?.setAttributes({
                "blobs.store": storeName,
                "blobs.method": "GET",
                "blobs.list.paginate": options?.paginate ?? false,
                "blobs.list.done": done,
                "blobs.list.cursor": currentCursor ?? void 0
              });
              if (done) {
                return { done: true, value: void 0 };
              }
              const nextParameters = { ...parameters };
              if (currentCursor !== null) {
                nextParameters.cursor = currentCursor;
              }
              const res = await client.makeRequest({
                method: "get",
                parameters: nextParameters,
                storeName
              });
              span?.setAttributes({
                "blobs.response.status": res.status
              });
              let blobs = [];
              let directories = [];
              if (![200, 204, 404].includes(res.status)) {
                await discardBody(res);
                throw new BlobsInternalError(res);
              }
              if (res.status === 404) {
                await discardBody(res);
                done = true;
              } else {
                const page = await res.json();
                if (page.next_cursor) {
                  currentCursor = page.next_cursor;
                } else {
                  done = true;
                }
                blobs = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
                directories = page.directories ?? [];
              }
              return {
                done: false,
                value: {
                  blobs,
                  directories
                }
              };
            });
          }
        };
      }
    };
  }
};
var getDeployStoreRegion = (clientOptions, context) => {
  if (clientOptions.region) {
    return clientOptions.region;
  }
  if (clientOptions.edgeURL || clientOptions.uncachedEdgeURL) {
    if (!context.primaryRegion) {
      throw new Error(
        "When accessing a deploy store, the Netlify Blobs client needs to be configured with a region, and one was not found in the environment. To manually set the region, set the `region` property in the store options. If you are using the Netlify CLI, you may have an outdated version; run `npm install -g netlify-cli@latest` to update and try again."
      );
    }
    return context.primaryRegion;
  }
  return REGION_AUTO;
};
var getStore = (input, options) => {
  if (typeof input === "string") {
    const contextOverride = options?.siteID && options?.token ? { siteID: options?.siteID, token: options?.token } : void 0;
    const clientOptions = getClientOptions(options ?? {}, contextOverride);
    const client = new Client(clientOptions);
    return new Store({ client, name: input });
  }
  if (typeof input?.name === "string") {
    const { name } = input;
    const contextOverride = input?.siteID && input?.token ? { siteID: input?.siteID, token: input?.token } : void 0;
    const clientOptions = getClientOptions(input, contextOverride);
    if (!name) {
      throw new MissingBlobsEnvironmentError(["name"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, name });
  }
  if (typeof input?.deployID === "string") {
    const context = getEnvironmentContext();
    const clientOptions = getClientOptions(input, context);
    const { deployID } = input;
    if (!deployID) {
      throw new MissingBlobsEnvironmentError(["deployID"]);
    }
    clientOptions.region = getDeployStoreRegion(clientOptions, context);
    const client = new Client(clientOptions);
    return new Store({ client, deployID });
  }
  throw new Error(
    "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
  );
};

// _netlify_build/db.src.mjs
var APP_JS = 'const {\n  useState,\n  useEffect,\n  useMemo,\n  useRef\n} = React;\nfunction IconBase(props) {\n  const {\n    size,\n    color,\n    style,\n    onClick,\n    title,\n    children\n  } = props;\n  const s = Object.assign({\n    fontSize: size || 14,\n    lineHeight: 1,\n    display: "inline-flex",\n    color: color || "inherit",\n    cursor: onClick ? "pointer" : undefined\n  }, style || {});\n  return /*#__PURE__*/React.createElement("span", {\n    onClick: onClick,\n    title: title,\n    style: s\n  }, children);\n}\nfunction Home(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F3E0}");\n}\nfunction Users(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F465}");\n}\nfunction GraduationCap(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F393}");\n}\nfunction Moon(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F319}");\n}\nfunction HeartHandshake(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F91D}");\n}\nfunction ClipboardList(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F4CB}");\n}\nfunction BarChart3(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F4CA}");\n}\nfunction X(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u2715");\n}\nfunction Plus(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "+");\n}\nfunction Trash2(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F5D1}\\uFE0F");\n}\nfunction BookOpen(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F4DA}");\n}\nfunction MapIcon(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F5FA}\\uFE0F");\n}\nfunction ChevronRight(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u203A");\n}\nfunction ChevronLeft(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u2039");\n}\nfunction Loader2(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u23F3");\n}\nfunction Save(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F4BE}");\n}\nfunction Download(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u2B07\\uFE0F");\n}\nfunction Upload(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u2B06\\uFE0F");\n}\nfunction Search(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F50D}");\n}\nfunction CheckSquare(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u2611\\uFE0F");\n}\nfunction CalendarCheck(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F4C5}");\n}\nfunction Trophy(p) {\n  return /*#__PURE__*/React.createElement(IconBase, p, "\\u{1F3C6}");\n}\nconst INK = "#1E3D36";\nconst INK_SOFT = "#2A4E45";\nconst PAPER = "#F7F5EF";\nconst CARD = "#FFFFFF";\nconst BORDER = "#E4E0D3";\nconst TEXT = "#26241C";\nconst TEXT_MUTED = "#736C5C";\nconst GOLD = "#B8862E";\nconst GOLD_BG = "#F5EBD6";\nconst GREEN = "#3F7A5C";\nconst GREEN_BG = "#E7F1EA";\nconst YELLOW = "#B4791E";\nconst YELLOW_BG = "#FBF0DA";\nconst RED = "#B5453D";\nconst RED_BG = "#FAE8E6";\nconst TARGET = 75;\nconst MAX_SANTRI = 38;\nconst CORE_SUBJECTS = ["Al-Qur\'an", "Imla\'", "Tamrin Lughoh", "Berhitung", "Bahasa Indonesia"];\nconst DEFAULT_SUBJECTS = ["Insya\'", "Tamrin Lughoh", "Imla\'", "Al-Qur\'an", "At-Tajwid", "At-Tafsir", "Al-Hadist", "Al-Fiqh", "At-Tauhid", "Tarikh al-Islam", "Al-Mahfudzot", "Al-Khot al-\'Aroby", "Reading", "Berhitung", "Matematika", "Fisika", "Sejarah", "Geografi", "Biologi", "Bahasa Indonesia"];\nconst EXAM_VALUES = Array.from({\n  length: 19\n}, (_, i) => (i + 2) * 5);\nconst labelOf = s => s === "Al-Qur\'an" ? "Al-Qur\'an (lisan)" : s; // Al-Qur\'an kelulusan = nilai lisan/syafahi\nconst PERHATIAN_MAX = 40; // nilai 40 ke bawah = perlu perhatian, di atas itu aman\nconst INTERVENSI_MIN_COUNT = 3; // 3 mapel atau lebih bernilai 40 ke bawah = perlu intervensi\nconst MIN_SETORAN_POIN = 3;\nconst PHASES = [{\n  name: "Pemetaan",\n  range: [1, 2],\n  milestone: null,\n  desc: "Assessment awal seluruh santri, belum ada target angka."\n}, {\n  name: "Perbaikan Dasar",\n  range: [3, 6],\n  milestone: 60,\n  desc: "Fokus penguatan dasar 5 mapel kelulusan."\n}, {\n  name: "Penguatan",\n  range: [7, 11],\n  milestone: 70,\n  desc: "Menaikkan target secara bertahap."\n}, {\n  name: "Simulasi Kelulusan",\n  range: [12, 14],\n  milestone: 75,\n  desc: "Tes berkala mendekati standar kelulusan."\n}, {\n  name: "Final Preparation",\n  range: [15, 16],\n  milestone: 75,\n  desc: "Pemantapan akhir sebelum penilaian kelulusan."\n}];\nfunction currentPhase(week) {\n  return PHASES.find(p => week >= p.range[0] && week <= p.range[1]) || PHASES[PHASES.length - 1];\n}\nfunction weakRegularSubjects(student) {\n  const latestBySubject = {};\n  student.regularScores.forEach(e => {\n    latestBySubject[e.subject] = e.value;\n  });\n  return Object.entries(latestBySubject).filter(([, v]) => v <= PERHATIAN_MAX).sort((a, b) => a[1] - b[1]).slice(0, 3).map(([subject, value]) => ({\n    subject,\n    value\n  }));\n}\nfunction genId() {\n  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;\n}\nfunction today() {\n  return new Date().toLocaleDateString("id-ID", {\n    day: "2-digit",\n    month: "short",\n    year: "numeric"\n  });\n}\nfunction statusOf(value) {\n  if (value === null || value === undefined) return "none";\n  return value <= PERHATIAN_MAX ? "red" : "green";\n}\nfunction statusColors(status) {\n  if (status === "green") return {\n    fg: GREEN,\n    bg: GREEN_BG\n  };\n  if (status === "yellow") return {\n    fg: YELLOW,\n    bg: YELLOW_BG\n  };\n  if (status === "red") return {\n    fg: RED,\n    bg: RED_BG\n  };\n  return {\n    fg: TEXT_MUTED,\n    bg: "#EFEDE5"\n  };\n}\nfunction latestExam(student, subject) {\n  const entries = student.examScores.filter(e => e.subject === subject);\n  if (!entries.length) return null;\n  return entries[entries.length - 1].value;\n}\n// nilai terakhir satu mapel (ujian bulanan/UTS dulu, lalu nilai akademik biasa)\nfunction latestScoreIn(student, subject, onlyUTS) {\n  const ex = student.examScores.filter(e => e.subject === subject && (!onlyUTS || e.month === "UTS"));\n  if (ex.length) return ex[ex.length - 1].value;\n  const reg = student.regularScores.filter(e => e.subject === subject && (!onlyUTS || e.date === "UTS"));\n  return reg.length ? reg[reg.length - 1].value : null;\n}\n// daftar {subject, value} nilai terakhir semua mapel yang sudah diinput\nfunction scoreList(student, onlyUTS) {\n  const names = [];\n  student.examScores.forEach(e => {\n    if (!names.includes(e.subject)) names.push(e.subject);\n  });\n  student.regularScores.forEach(e => {\n    if (!names.includes(e.subject)) names.push(e.subject);\n  });\n  return names.map(subject => ({\n    subject,\n    value: latestScoreIn(student, subject, onlyUTS)\n  })).filter(r => r.value !== null);\n}\nfunction overallStatus(student) {\n  const list = scoreList(student, false);\n  if (!list.length) return "perhatian";\n  const weak = list.filter(r => r.value <= PERHATIAN_MAX).length;\n  if (weak >= INTERVENSI_MIN_COUNT) return "intervensi";\n  if (weak >= 1) return "perhatian";\n  return "aman";\n}\n\n// ---- Kelas malam: 3 mapel kelulusan, 1 tugas wajib per hari bagi santri yang nilainya kecil ----\nconst KELAS_MALAM_SUBJECTS = [{\n  subject: "Berhitung",\n  code: "berhitung",\n  label: "Berhitung"\n}, {\n  subject: "Imla\'",\n  code: "imla",\n  label: "Imla\'"\n}, {\n  subject: "Al-Qur\'an",\n  code: "quran",\n  label: "Al-Qur\'an (lisan)"\n}];\nconst tugasKey = (dateKey, def) => dateKey + "_" + def.code;\n// santri yang masuk kelas malam sebuah mapel (nilai terakhir <= batas), nilai terendah di atas\nfunction kelasMalamMembers(students, subject, batas) {\n  return students.map(s => ({\n    student: s,\n    value: latestScoreIn(s, subject, false)\n  })).filter(r => r.value !== null && r.value <= batas).sort((a, b) => a.value - b.value || a.student.name.localeCompare(b.student.name));\n}\n// label mapel yang tugasnya BELUM diselesaikan santri pada tanggal itu (tugas hanya berlaku kalau teksnya sudah diisi)\nfunction pendingTugas(student, dateKey, config) {\n  const batas = config.kelasMalamBatas;\n  return KELAS_MALAM_SUBJECTS.filter(def => {\n    const text = (config.tugasMalam || {})[tugasKey(dateKey, def)];\n    if (!text || !String(text).trim()) return false;\n    const v = latestScoreIn(student, def.subject, false);\n    if (v === null || v > batas) return false;\n    return !(student.kelasMalam || []).some(e => e.dateKey === dateKey && e.subject === def.subject);\n  }).map(def => def.label);\n}\nfunction emptyStudent(name, noDaftar = null) {\n  return {\n    id: genId(),\n    name,\n    noDaftar,\n    regularScores: [],\n    examScores: [],\n    nightStudy: [],\n    akhlak: [],\n    tingkahLaku: [],\n    kebersihan: [],\n    targets: [],\n    izinPiket: [],\n    ibadah: [],\n    baseline: null,\n    setoran: [],\n    absensi: [],\n    kelasMalam: []\n  };\n}\nfunction emptyStudentData(name, noDaftar) {\n  return {\n    name,\n    noDaftar: noDaftar || null,\n    regularScores: [],\n    examScores: [],\n    nightStudy: [],\n    akhlak: [],\n    tingkahLaku: [],\n    kebersihan: [],\n    targets: [],\n    izinPiket: [],\n    ibadah: [],\n    baseline: null,\n    setoran: [],\n    absensi: [],\n    kelasMalam: []\n  };\n}\nconst SEED_STUDENTS = [["1051", "Muhammad Abi Dzar Alfiansyah"], ["529", "Muhammad Jafar Al Khoyyar"], ["920", "Muhammad Ramadhan"], ["1799", "Muhammad Nizam Rizqullah"], ["1005", "Fattiar Ilhamzah Wardhana"], ["623", "Adil Zidan Hadvan Aziz"], ["1003", "Fahmi Amanudien Shodiq"], ["1047", "Muhammad Zaky Risnandar"], ["1157", "Najib Ahnaf Al-Azmi"], ["1159", "Saifudin Abdullah"], ["720", "Farhan Raditya"], ["1018", "Alkhalifi Zaki Hamizan"], ["836", "Panji Pradipta Mursidi"], ["725", "Arkan Hikary Aruci"], ["780", "Antariksa Kevindra Nararrya"], ["1379", "Nashif Fikar Ad-Dien"], ["1871", "Abdillah Baladitya Musthofa"], ["216", "Kenji Kurnia Muammar"], ["263", "Fahri Azzam Hidayatullah"], ["271", "Muhamad Elfatih Altofurrayaan"], ["275", "Ali Azfar"], ["812", "Muhammad Faatihul Ariq"], ["1344", "Syabil Khafadi Akmal"], ["1359", "Muhamad Zikhal Al-Azhar"], ["1464", "Galih Ilham Maulana"], ["1803", "Lucky Hadi Mandala"], ["1830", "Muhammad Azzam Faiz Widodo"], ["1873", "Muhammad Ilisyam Faiq Adlan"], ["89", "Abdullah Alrasyid"], ["203", "Ridwan Al Farisi"], ["209", "Moh. Hanif Nazmi"], ["237", "Maulana Rahman Hakim"], ["241", "Fairus Akmar"], ["273", "Muhammad Akbar Fuady Sokheh"], ["280", "Fayyaz Muhammad Asna Ali"], ["768", "Raditya Naufal Widiananta"], ["796", "Pramuditva Agra Sudiro"], ["863", "Desha Ariaian Maulana"]];\n\n// Nilai penempatan awal tahun (dari rapor kelas asal, sebelum masuk B15)\nconst BASELINE_DATA = [{\n  name: "Muhammad Nizam Rizqullah",\n  kelasAwal: "B20",\n  ibadah: 70,\n  berhitung: 50,\n  imla: 70,\n  rataRata: 46.04,\n  kelulusan: "C",\n  ketKelulusan: "Lulus",\n  akselerasi: "I",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 1\n}, {\n  name: "Fattar Ilhamzah Wardhana",\n  kelasAwal: "B13",\n  ibadah: 80,\n  berhitung: 45,\n  imla: 70,\n  rataRata: 55.21,\n  kelulusan: "D",\n  ketKelulusan: "Lulus",\n  akselerasi: "I",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 2\n}, {\n  name: "Adil Zidan Hadvan Aziz",\n  kelasAwal: "B8",\n  ibadah: 65,\n  berhitung: 35,\n  imla: 65,\n  rataRata: 52.50,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "I",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 3\n}, {\n  name: "Fahmi Amanudien Shodiq",\n  kelasAwal: "B13",\n  ibadah: 80,\n  berhitung: 20,\n  imla: 70,\n  rataRata: 52.92,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "I",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 4\n}, {\n  name: "Muhammad Zaky Risnandar",\n  kelasAwal: "B13",\n  ibadah: 65,\n  berhitung: 20,\n  imla: 75,\n  rataRata: 49.79,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "I",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 5\n}, {\n  name: "Najib Ahnaf Al-Azmi",\n  kelasAwal: "B15",\n  ibadah: 75,\n  berhitung: 35,\n  imla: 55,\n  rataRata: 55.00,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "I",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 6\n}, {\n  name: "Saifudin Abdullah",\n  kelasAwal: "B15",\n  ibadah: 75,\n  berhitung: 45,\n  imla: 65,\n  rataRata: 52.29,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "I",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 7\n}, {\n  name: "Farhan Raditya",\n  kelasAwal: "B8",\n  ibadah: 80,\n  berhitung: 30,\n  imla: 40,\n  rataRata: 47.71,\n  kelulusan: "L",\n  ketKelulusan: "Lulus",\n  akselerasi: "I",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 8\n}, {\n  name: "Alkhalifi Zaki Hamizan",\n  kelasAwal: "B13",\n  ibadah: 70,\n  berhitung: 65,\n  imla: 85,\n  rataRata: 55.00,\n  kelulusan: "B",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 9\n}, {\n  name: "Panji Pradipta Mursidi",\n  kelasAwal: "B11",\n  ibadah: 80,\n  berhitung: 50,\n  imla: 80,\n  rataRata: 53.96,\n  kelulusan: "C",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 10\n}, {\n  name: "Arkan Hikari Aruci",\n  kelasAwal: "B10",\n  ibadah: 75,\n  berhitung: 55,\n  imla: 60,\n  rataRata: 52.71,\n  kelulusan: "D",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 11\n}, {\n  name: "Antariksa Kevindra Nararrya",\n  kelasAwal: "B10",\n  ibadah: 75,\n  berhitung: 60,\n  imla: 65,\n  rataRata: 52.29,\n  kelulusan: "D",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 12\n}, {\n  name: "Nashif Fikar Ad-Dien",\n  kelasAwal: "B17",\n  ibadah: 75,\n  berhitung: 55,\n  imla: 55,\n  rataRata: 49.79,\n  kelulusan: "D",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 13\n}, {\n  name: "Abdillah Baladitya Musthofa",\n  kelasAwal: "B21",\n  ibadah: 80,\n  berhitung: 45,\n  imla: 50,\n  rataRata: 52.1,\n  kelulusan: "D",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 14\n}, {\n  name: "Kenji Kurnia Muammar",\n  kelasAwal: "B4",\n  ibadah: 80,\n  berhitung: 55,\n  imla: 65,\n  rataRata: 49.17,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 15\n}, {\n  name: "Fahri Azzam Hidayatullah",\n  kelasAwal: "B4",\n  ibadah: 70,\n  berhitung: 45,\n  imla: 70,\n  rataRata: 50.00,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 16\n}, {\n  name: "Muhamad Elfatih Altofurrayaan",\n  kelasAwal: "B4",\n  ibadah: 55,\n  berhitung: 50,\n  imla: 50,\n  rataRata: 42.50,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 17\n}, {\n  name: "Ali Azfar",\n  kelasAwal: "B4",\n  ibadah: 65,\n  berhitung: 55,\n  imla: 75,\n  rataRata: 49.58,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 18\n}, {\n  name: "Muhammad Faatihul Ariq",\n  kelasAwal: "B11",\n  ibadah: 75,\n  berhitung: 40,\n  imla: 90,\n  rataRata: 58.54,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 19\n}, {\n  name: "Syabil Khafadi Akmal",\n  kelasAwal: "B17",\n  ibadah: 75,\n  berhitung: 35,\n  imla: 50,\n  rataRata: 47.08,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 20\n}, {\n  name: "Muhamad Zikhal Al-Azhar",\n  kelasAwal: "B17",\n  ibadah: 55,\n  berhitung: 40,\n  imla: 55,\n  rataRata: 48.33,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 21\n}, {\n  name: "Galih Ilham Maulana",\n  kelasAwal: "B18",\n  ibadah: 75,\n  berhitung: 50,\n  imla: 50,\n  rataRata: 52.29,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 22\n}, {\n  name: "Lucky Hadi Mandala",\n  kelasAwal: "B20",\n  ibadah: 70,\n  berhitung: 55,\n  imla: 50,\n  rataRata: 47.29,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 23\n}, {\n  name: "Muhammad Azzam Faiz Widodo",\n  kelasAwal: "B20",\n  ibadah: 70,\n  berhitung: 35,\n  imla: 75,\n  rataRata: 46.04,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 24\n}, {\n  name: "Muhammad Hisyam Faiq Adlan",\n  kelasAwal: "B21",\n  ibadah: 80,\n  berhitung: 30,\n  imla: 70,\n  rataRata: 53.5,\n  kelulusan: "E",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 25\n}, {\n  name: "Abdullah Alrasyid",\n  kelasAwal: "B2",\n  ibadah: 70,\n  berhitung: 35,\n  imla: 60,\n  rataRata: 49.38,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 26\n}, {\n  name: "Ridwan Al Farisi",\n  kelasAwal: "B4",\n  ibadah: 70,\n  berhitung: 35,\n  imla: 70,\n  rataRata: 52.29,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 27\n}, {\n  name: "Moh. Hanif Nazmi",\n  kelasAwal: "B4",\n  ibadah: 75,\n  berhitung: 35,\n  imla: 50,\n  rataRata: 45.63,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 28\n}, {\n  name: "Maulana Rahman Hakim",\n  kelasAwal: "B4",\n  ibadah: 80,\n  berhitung: 35,\n  imla: 65,\n  rataRata: 45.63,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 29\n}, {\n  name: "Fairus Akmar",\n  kelasAwal: "B4",\n  ibadah: 50,\n  berhitung: 45,\n  imla: 55,\n  rataRata: 43.75,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 30\n}, {\n  name: "Muhammad Akbar Fuady Sokheh",\n  kelasAwal: "B4",\n  ibadah: 75,\n  berhitung: 35,\n  imla: 65,\n  rataRata: 48.54,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 31\n}, {\n  name: "Fayyaz Muhammad Asna Ali",\n  kelasAwal: "B4",\n  ibadah: 55,\n  berhitung: 25,\n  imla: 60,\n  rataRata: 47.29,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 32\n}, {\n  name: "Raditya Naufal Widiananta",\n  kelasAwal: "B10",\n  ibadah: 75,\n  berhitung: 35,\n  imla: 50,\n  rataRata: 45.63,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 33\n}, {\n  name: "Pramuditva Agra Sudiro",\n  kelasAwal: "B10",\n  ibadah: 60,\n  berhitung: 25,\n  imla: 65,\n  rataRata: 51.25,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 34\n}, {\n  name: "Destha Ariaian Maulana",\n  kelasAwal: "B11",\n  ibadah: 75,\n  berhitung: 25,\n  imla: 75,\n  rataRata: 48.13,\n  kelulusan: "F",\n  ketKelulusan: "Lulus",\n  akselerasi: "X",\n  ketAkselerasi: "Tidak Aksel",\n  noAbsen: 35\n}];\n\n// Nilai UTS FINAL (file murajaah fiks). Baris: [noDaftar, lalu 15 nilai sesuai urutan subjects di UTS_BATCHES]\nconst UTS_FINAL = [["1051", 45, 75, 25, 55, 70, 20, 40, 70, 65, 60, 50, 25, 40, 40, 70], ["529", 45, 40, 65, 55, 75, 35, 20, 75, 60, 60, 55, 55, 20, 45, 70], ["920", 50, 50, 50, 50, 45, 25, 30, 55, 45, 70, 35, 55, 25, 35, 50], ["1799", 35, 70, 75, 65, 50, 45, 35, 80, 45, 60, 50, 70, 35, 25, 40], ["1005", 55, 55, 70, 85, 80, 20, 50, 65, 70, 70, 65, 80, 30, 65, 70], ["623", 50, 70, 65, 45, 60, 35, 35, 60, 70, 60, 60, 75, 25, 55, 50], ["1003", 50, 65, 65, 60, 70, 40, 40, 75, 55, 70, 60, 70, 40, 45, 50], ["1047", 40, 55, 65, 75, 70, 35, 35, 85, 75, 60, 60, 90, 70, 65, 70], ["1157", 55, 85, 85, 65, 80, 55, 85, 85, 90, 70, 65, 90, 70, 65, 70], ["1159", 50, 55, 70, 60, 45, 40, 35, 70, 70, 50, 60, 65, 30, 75, 70], ["720", 35, 20, 60, 45, 65, 20, 20, 65, 35, 60, 50, 45, 15, 20, 70], ["1018", 45, 75, 90, 75, 75, 50, 85, 90, 70, 70, 75, 85, 90, 80, 70], ["836", 50, 55, 75, 65, 80, 30, 65, 70, 75, 40, 50, 70, 40, 55, 70], ["725", 45, 60, 65, 50, 65, 25, 40, 40, 45, 70, 55, 90, 25, 40, 70], ["780", 35, 50, 80, 80, 40, 30, 15, 55, 50, 60, 55, 70, 40, 40, 70], ["1379", 45, 70, 75, 60, 75, 30, 65, 65, 60, 60, 50, 80, 55, 65, 70], ["1871", 45, 55, 75, 75, 85, 35, 35, 60, 50, 70, 65, 90, 85, 30, 70], ["216", 40, 55, 75, 60, 65, 20, 45, 75, 60, 70, 55, 65, 40, 30, 70], ["263", 55, 50, 75, 45, 70, 20, 50, 70, 40, 60, 55, 35, 40, 30, 70], ["271", 35, 55, 70, 55, 65, 30, 25, 55, 35, 50, 50, 70, 50, 45, 70], ["275", 40, 70, 75, 60, 65, 35, 30, 90, 50, 60, 60, 85, 50, 35, 70], ["812", 55, 50, 70, 45, 70, 30, 75, 80, 85, 70, 70, 80, 30, 65, 70], ["1344", 45, 60, 75, 65, 55, 30, 20, 60, 55, 50, 60, 60, 30, 25, 70], ["1359", 45, 80, 85, 55, 75, 30, 80, 60, 55, 70, 55, 80, 50, 55, 70], ["1464", 45, 50, 65, 55, 55, 55, 50, 65, 85, 70, 70, 85, 60, 55, 70], ["1803", 45, 60, 80, 65, 70, 45, 40, 80, 70, 50, 65, 90, 55, 55, 70], ["1830", 40, 60, 55, 65, 70, 25, 60, 90, 80, 70, 70, 85, 50, 35, 70], ["1873", 45, 60, 70, 75, 65, 40, 50, 75, 65, 50, 55, 85, 60, 40, 70], ["89", 45, 75, 45, 70, 65, 30, 40, 60, 50, 40, 70, 15, 50, 65, 70], ["203", 45, 30, 75, 65, 50, 25, 35, 75, 55, 40, 70, 50, 40, 35, 70], ["209", 45, 60, 55, 55, 45, 30, 20, 40, 55, 50, 65, 70, 45, 45, 70], ["237", 50, 35, 60, 55, 60, 15, 20, 55, 45, 70, 65, 65, 30, 25, 70], ["241", 45, 45, 70, 55, 50, 30, 30, 45, 35, 20, 50, 45, 35, 25, 70], ["273", 40, 40, 85, 65, 85, 50, 30, 65, 35, 40, 65, 95, 40, 40, 70], ["280", 50, 40, 70, 85, 60, 20, 20, 60, 55, 40, 55, 85, 40, 30, 70], ["768", 35, 50, 70, 55, 70, 20, 30, 40, 45, 40, 45, 60, 30, 40, 70], ["796", 45, 70, 80, 85, 80, 30, 20, 55, 35, 20, 45, 75, 45, 25, 70], ["863", 35, 55, 90, 75, 80, 30, 50, 75, 85, 70, 75, 85, 55, 45, 70]];\n\n// type: "exam" = ujian (mapel kelulusan), "regular" = nilai akademik biasa. clear = hapus semua nilai lama mapel itu\n// (kecuali riwayat "Awal Tahun") supaya nilai tidak numpuk, lalu isi satu nilai fiks berlabel "UTS".\nconst UTS_BATCHES = [{\n  title: "UTS Final \\u00b7 15 mapel (nilai fiks)",\n  desc: "Insya\', T. Lughoh, B. Indonesia, Reading, Fiqih, Berhitung, Al-Qur\'an tulis & lisan, Imla\', Tauhid, Tajwid, Matematika, Fisika, Mahfudzot, Ibadah harian. Menghapus nilai lama mapel-mapel ini dan menggantinya.",\n  subjects: [["Insya\'", "regular", {\n    clear: true\n  }], ["Tamrin Lughoh", "exam", {\n    clear: true\n  }], ["Bahasa Indonesia", "exam", {\n    clear: true\n  }], ["Reading", "regular", {\n    clear: true\n  }], ["Al-Fiqh", "regular", {\n    clear: true\n  }], ["Berhitung", "exam", {\n    clear: true\n  }], ["Al-Qur\'an (tulis)", "regular", {\n    clear: true\n  }], ["Imla\'", "exam", {\n    clear: true\n  }], ["At-Tauhid", "regular", {\n    clear: true\n  }], ["Al-Qur\'an", "exam", {\n    clear: true\n  }], ["At-Tajwid", "regular", {\n    clear: true\n  }], ["Matematika", "regular", {\n    clear: true\n  }], ["Fisika", "regular", {\n    clear: true\n  }], ["Al-Mahfudzot", "regular", {\n    clear: true\n  }], ["Ibadah Harian", "regular", {\n    clear: true\n  }]],\n  rows: UTS_FINAL\n}];\n\n// Cek kesesuaian data live dengan satu batch: tiap mapel harus punya tepat 1 nilai (selain "Awal Tahun") dan nilainya sama.\nfunction auditBatch(students, batch) {\n  let total = 0,\n    ok = 0,\n    stacked = 0;\n  batch.rows.forEach(row => {\n    const s = students.find(x => x.noDaftar === row[0]);\n    if (!s) return;\n    batch.subjects.forEach(([subject, type], i) => {\n      total++;\n      const ex = s.examScores.filter(e => e.subject === subject && e.month !== "Awal Tahun");\n      const rg = s.regularScores.filter(e => e.subject === subject && e.date !== "Awal Tahun");\n      const all = [...ex, ...rg];\n      if (all.length > 1) stacked++;\n      const mine = type === "exam" ? ex : rg;\n      if (all.length === 1 && mine.length === 1 && mine[0].value === row[i + 1]) ok++;\n    });\n  });\n  return {\n    total,\n    ok,\n    bad: total - ok,\n    stacked\n  };\n}\nfunction normWords(name) {\n  return name.toLowerCase().replace(/[^a-z\\s\'-]/g, "").split(/\\s+/).filter(Boolean);\n}\nfunction findBestMatch(name, students) {\n  const target = normWords(name);\n  let best = null,\n    bestScore = 0;\n  students.forEach(st => {\n    const words = normWords(st.name);\n    const common = words.filter(w => target.includes(w)).length;\n    const score = common / Math.max(words.length, target.length);\n    if (score > bestScore) {\n      bestScore = score;\n      best = st;\n    }\n  });\n  return bestScore >= 0.6 ? best : null;\n}\nfunction Dot({\n  status\n}) {\n  const {\n    fg,\n    bg\n  } = statusColors(status);\n  const symbol = status === "green" ? "\\u2713" : status === "yellow" ? "!" : status === "red" ? "\\u2715" : "\\u00b7";\n  return /*#__PURE__*/React.createElement("span", {\n    style: {\n      display: "inline-flex",\n      alignItems: "center",\n      justifyContent: "center",\n      width: 22,\n      height: 22,\n      borderRadius: 6,\n      background: bg,\n      color: fg,\n      fontSize: 11,\n      fontWeight: 600\n    }\n  }, symbol);\n}\nfunction ProgressBar({\n  pct,\n  color = INK,\n  track = "#EDEAE0",\n  height = 8\n}) {\n  const clamped = Math.max(0, Math.min(100, Math.round(pct || 0)));\n  return /*#__PURE__*/React.createElement("div", {\n    style: {\n      width: "100%",\n      height,\n      borderRadius: height,\n      background: track,\n      overflow: "hidden"\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      width: `${clamped}%`,\n      height: "100%",\n      background: color,\n      borderRadius: height\n    }\n  }));\n}\nfunction StatCard({\n  label,\n  value,\n  accent\n}) {\n  return /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      padding: "16px 18px",\n      flex: 1,\n      minWidth: 120\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 6\n    }\n  }, label), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 28,\n      color: accent || TEXT,\n      lineHeight: 1\n    }\n  }, value));\n}\nfunction IconBtn({\n  onClick,\n  title,\n  danger\n}) {\n  return /*#__PURE__*/React.createElement("button", {\n    onClick: onClick,\n    title: title || "Hapus",\n    style: {\n      border: "none",\n      background: "transparent",\n      cursor: "pointer",\n      color: danger === false ? TEXT_MUTED : RED,\n      padding: 4,\n      display: "flex",\n      alignItems: "center"\n    }\n  }, /*#__PURE__*/React.createElement(Trash2, {\n    size: 14\n  }));\n}\nfunction ConfirmDelete({\n  onConfirm,\n  onCancel\n}) {\n  return /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 6\n    }\n  }, /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 12,\n      color: RED\n    }\n  }, "Yakin?"), /*#__PURE__*/React.createElement("button", {\n    onClick: onConfirm,\n    style: {\n      border: "none",\n      background: RED,\n      color: "#fff",\n      borderRadius: 5,\n      padding: "3px 8px",\n      fontSize: 11,\n      cursor: "pointer"\n    }\n  }, "Hapus"), /*#__PURE__*/React.createElement("button", {\n    onClick: onCancel,\n    style: {\n      border: `1px solid ${BORDER}`,\n      background: "#fff",\n      color: TEXT_MUTED,\n      borderRadius: 5,\n      padding: "3px 8px",\n      fontSize: 11,\n      cursor: "pointer"\n    }\n  }, "Batal"));\n}\nfunction Toast({\n  message\n}) {\n  if (!message) return null;\n  return /*#__PURE__*/React.createElement("div", {\n    style: {\n      position: "fixed",\n      top: 18,\n      right: 18,\n      background: INK,\n      color: "#fff",\n      padding: "10px 16px",\n      borderRadius: 8,\n      fontSize: 13,\n      zIndex: 50,\n      boxShadow: "0 4px 14px rgba(0,0,0,0.18)"\n    }\n  }, message);\n}\nfunction Field({\n  label,\n  children\n}) {\n  return /*#__PURE__*/React.createElement("label", {\n    style: {\n      display: "flex",\n      flexDirection: "column",\n      gap: 4,\n      fontSize: 12,\n      color: TEXT_MUTED,\n      flex: 1,\n      minWidth: 100\n    }\n  }, label, children);\n}\nconst inputStyle = {\n  border: `1px solid ${BORDER}`,\n  borderRadius: 6,\n  padding: "7px 9px",\n  fontSize: 13,\n  fontFamily: "inherit",\n  background: "#FFFFFF",\n  color: TEXT\n};\nconst NAV_ITEMS = [{\n  key: "dashboard",\n  label: "Dashboard",\n  icon: Home\n}, {\n  key: "peringkat",\n  label: "Peringkat Nilai",\n  icon: Trophy\n}, {\n  key: "santri",\n  label: "Data Santri",\n  icon: Users\n}, {\n  key: "absen",\n  label: "Absen Harian",\n  icon: CalendarCheck\n}, {\n  key: "setoran",\n  label: "Setoran Harian",\n  icon: CheckSquare\n}, {\n  key: "kelasMalam",\n  label: "Kelas Malam",\n  icon: Moon\n}, {\n  key: "inputMassal",\n  label: "Input Nilai Massal",\n  icon: ClipboardList\n}, {\n  key: "ujianMassal",\n  label: "Ujian Bulanan Massal",\n  icon: GraduationCap\n}, {\n  key: "mapel",\n  label: "Mata Pelajaran",\n  icon: BookOpen\n}, {\n  key: "roadmap",\n  label: "Roadmap 16 Minggu",\n  icon: MapIcon\n}, {\n  key: "analitik",\n  label: "Analitik Kelas",\n  icon: BarChart3\n}, {\n  key: "backup",\n  label: "Cadangan Data",\n  icon: Save\n}];\nfunction App() {\n  const [db, setDb] = useState(null);\n  const [dbStatus, setDbStatus] = useState("connecting");\n  const [students, setStudents] = useState([]);\n  const [subjects, setSubjects] = useState(DEFAULT_SUBJECTS);\n  const [currentWeek, setCurrentWeekState] = useState(1);\n  const [studentsLoaded, setStudentsLoaded] = useState(false);\n  const [configLoaded, setConfigLoaded] = useState(false);\n  const [configExists, setConfigExists] = useState(false);\n  const [kelasConfig, setKelasConfigState] = useState({\n    tugasMalam: {},\n    kelasMalamBatas: PERHATIAN_MAX\n  });\n  const [view, setView] = useState("dashboard");\n  const [selectedId, setSelectedId] = useState(null);\n  const [newName, setNewName] = useState("");\n  const [searchQuery, setSearchQuery] = useState("");\n  const [pendingDeleteId, setPendingDeleteId] = useState(null);\n  const [toast, setToast] = useState("");\n  const seededRef = useRef(false);\n  function showToast(msg) {\n    setToast(msg);\n    setTimeout(() => setToast(""), 2600);\n  }\n  useEffect(() => {\n    let cancelled = false;\n    (async () => {\n      try {\n        const cap = await claude.use("db");\n        if (cancelled) return;\n        if (!cap) {\n          setDbStatus("unavailable");\n          return;\n        }\n        setDb(cap);\n        setDbStatus("ready");\n      } catch (e) {\n        if (!cancelled) setDbStatus("unavailable");\n      }\n    })();\n    return () => {\n      cancelled = true;\n    };\n  }, []);\n  useEffect(() => {\n    if (!db) return;\n    const unsubStudents = db.collection("students").onSnapshot(snap => {\n      const list = snap.docs.map(d => {\n        const body = d.data() || {};\n        return Object.assign({}, emptyStudentData(body.name, body.noDaftar), body, {\n          id: d.id\n        });\n      });\n      setStudents(list);\n      setStudentsLoaded(true);\n    }, () => {\n      setStudentsLoaded(true);\n    });\n    const unsubConfig = db.doc("meta/config").onSnapshot(snap => {\n      if (snap.exists) {\n        const cfg = snap.data();\n        setSubjects(cfg.subjects || DEFAULT_SUBJECTS);\n        setCurrentWeekState(cfg.currentWeek || 1);\n        setKelasConfigState({\n          tugasMalam: cfg.tugasMalam || {},\n          kelasMalamBatas: cfg.kelasMalamBatas || PERHATIAN_MAX\n        });\n        setConfigExists(true);\n      } else {\n        setConfigExists(false);\n      }\n      setConfigLoaded(true);\n    }, () => {\n      setConfigLoaded(true);\n    });\n    return () => {\n      unsubStudents();\n      unsubConfig();\n    };\n  }, [db]);\n  useEffect(() => {\n    if (!db || !studentsLoaded || !configLoaded || seededRef.current) return;\n    seededRef.current = true;\n    (async () => {\n      const tasks = [];\n      if (students.length === 0) {\n        SEED_STUDENTS.forEach(([noDaftar, name]) => {\n          tasks.push(db.doc("students/" + noDaftar).set(emptyStudentData(name, noDaftar)));\n        });\n      }\n      if (!configExists) {\n        tasks.push(db.doc("meta/config").set({\n          subjects: DEFAULT_SUBJECTS,\n          currentWeek: 1\n        }));\n      }\n      try {\n        await Promise.all(tasks);\n      } catch (e) {\n        showToast("Gagal menyiapkan data awal.");\n      }\n    })();\n  }, [db, studentsLoaded, configLoaded]);\n  if (dbStatus === "unavailable") {\n    return /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        alignItems: "center",\n        justifyContent: "center",\n        minHeight: "100vh",\n        padding: 24,\n        background: PAPER\n      }\n    }, /*#__PURE__*/React.createElement("div", {\n      style: {\n        maxWidth: 380,\n        textAlign: "center",\n        color: TEXT_MUTED,\n        fontSize: 14\n      }\n    }, /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 32,\n        marginBottom: 10\n      }\n    }, "\\u26A0\\uFE0F"), "Halaman ini butuh akses database bersama yang belum tersedia untuk tampilan ini. Coba buka lagi lewat link aslinya, atau hubungi pemilik halaman."));\n  }\n  if (dbStatus !== "ready" || !studentsLoaded || !configLoaded) {\n    return /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        alignItems: "center",\n        justifyContent: "center",\n        minHeight: "100vh",\n        color: TEXT_MUTED,\n        gap: 8,\n        background: PAPER\n      }\n    }, /*#__PURE__*/React.createElement(Loader2, {\n      size: 16\n    }), " Memuat data...");\n  }\n  const selected = students.find(s => s.id === selectedId) || null;\n  function addStudent() {\n    const name = newName.trim();\n    if (!name) return;\n    if (students.length >= MAX_SANTRI) {\n      showToast(`Sudah mencapai batas maksimal ${MAX_SANTRI} santri.`);\n      return;\n    }\n    db.doc("students/" + genId()).set(emptyStudentData(name, null)).catch(() => showToast("Gagal menambah santri."));\n    setNewName("");\n  }\n  function deleteStudent(id) {\n    db.doc("students/" + id).delete().catch(() => showToast("Gagal menghapus santri."));\n    if (selectedId === id) setSelectedId(null);\n    setPendingDeleteId(null);\n    showToast("Santri dan seluruh data terkait telah dihapus.");\n  }\n  function renameSubject(index, name) {\n    const next = [...subjects];\n    next[index] = name;\n    db.doc("meta/config").update({\n      subjects: next\n    }).catch(() => showToast("Gagal menyimpan nama mapel."));\n  }\n  function addEntry(studentId, listKey, entry) {\n    const student = students.find(s => s.id === studentId);\n    if (!student) return;\n    const newList = [...(student[listKey] || []), {\n      id: genId(),\n      ...entry\n    }];\n    db.doc("students/" + studentId).update({\n      [listKey]: newList\n    }).catch(() => showToast("Gagal menyimpan."));\n  }\n  function deleteEntry(studentId, listKey, entryId) {\n    const student = students.find(s => s.id === studentId);\n    if (!student) return;\n    const newList = (student[listKey] || []).filter(e => e.id !== entryId);\n    db.doc("students/" + studentId).update({\n      [listKey]: newList\n    }).catch(() => showToast("Gagal menghapus."));\n  }\n  function saveExamScore(studentId, subject, month, value) {\n    const student = students.find(s => s.id === studentId);\n    if (!student) return Promise.resolve();\n    const filtered = student.examScores.filter(e => !(e.subject === subject && e.month === month));\n    const newList = [...filtered, {\n      id: genId(),\n      subject,\n      value,\n      month\n    }];\n    return db.doc("students/" + studentId).update({\n      examScores: newList\n    }).catch(() => showToast("Gagal menyimpan nilai ujian."));\n  }\n  function importUTSBatch(batch) {\n    let matched = 0;\n    const unmatched = [];\n    const tasks = [];\n    batch.rows.forEach(row => {\n      const target = students.find(s => s.noDaftar === row[0]);\n      if (!target) {\n        unmatched.push(row[0]);\n        return;\n      }\n      matched++;\n      let exam = target.examScores;\n      let reg = target.regularScores;\n      batch.subjects.forEach(([subject, type, opts], i) => {\n        const value = row[i + 1];\n        if (opts && opts.clear) {\n          exam = exam.filter(e => !(e.subject === subject && e.month !== "Awal Tahun"));\n          reg = reg.filter(e => !(e.subject === subject && e.date !== "Awal Tahun"));\n        }\n        if (type === "exam") {\n          exam = [...exam.filter(e => !(e.subject === subject && e.month === "UTS")), {\n            id: genId(),\n            subject,\n            value,\n            month: "UTS"\n          }];\n        } else {\n          reg = [...reg.filter(e => !(e.subject === subject && e.date === "UTS")), {\n            id: genId(),\n            subject,\n            value,\n            date: "UTS"\n          }];\n        }\n      });\n      tasks.push(db.doc("students/" + target.id).update({\n        examScores: exam,\n        regularScores: reg\n      }));\n    });\n    Promise.all(tasks).then(() => showToast(`${batch.title}: tersimpan untuk ${matched} santri (menimpa nilai UTS lama jika ada)${unmatched.length ? `. Tidak cocok: ${unmatched.join(", ")}` : ""}`)).catch(() => showToast("Sebagian nilai UTS gagal tersimpan, coba lagi."));\n  }\n  function setAbsen(studentId, dateKey, status, keterangan) {\n    const student = students.find(s => s.id === studentId);\n    if (!student) return;\n    const filtered = (student.absensi || []).filter(e => e.dateKey !== dateKey);\n    const newList = [...filtered, {\n      id: genId(),\n      dateKey,\n      status,\n      keterangan: keterangan || ""\n    }];\n    db.doc("students/" + studentId).update({\n      absensi: newList\n    }).catch(() => showToast("Gagal menyimpan absen."));\n  }\n  function setCurrentWeek(week) {\n    const clamped = Math.max(1, Math.min(16, week));\n    db.doc("meta/config").update({\n      currentWeek: clamped\n    }).catch(() => showToast("Gagal menyimpan minggu."));\n  }\n  function setKelasConfig(patch) {\n    db.doc("meta/config").update(patch).catch(() => showToast("Gagal menyimpan pengaturan kelas malam."));\n  }\n  function toggleKelasMalam(studentId, dateKey, subject) {\n    const student = students.find(s => s.id === studentId);\n    if (!student) return;\n    const list = student.kelasMalam || [];\n    const has = list.some(e => e.dateKey === dateKey && e.subject === subject);\n    const newList = has ? list.filter(e => !(e.dateKey === dateKey && e.subject === subject)) : [...list, {\n      id: genId(),\n      dateKey,\n      subject\n    }];\n    db.doc("students/" + studentId).update({\n      kelasMalam: newList\n    }).catch(() => showToast("Gagal menyimpan centang tugas."));\n  }\n  function importBaselineData() {\n    const usedIds = new Set();\n    const updates = [];\n    let matched = 0;\n    const unmatched = [];\n    BASELINE_DATA.forEach(b => {\n      const candidates = students.filter(s => !usedIds.has(s.id));\n      let target = candidates.find(s => s.name.trim().toLowerCase() === b.name.trim().toLowerCase());\n      if (!target) target = findBestMatch(b.name, candidates);\n      if (!target) {\n        unmatched.push(b.name);\n        return;\n      }\n      usedIds.add(target.id);\n      if (target.baseline) return;\n      matched++;\n      const hasBerhitungAwal = target.examScores.some(e => e.subject === "Berhitung" && e.month === "Awal Tahun");\n      const hasImlaAwal = target.examScores.some(e => e.subject === "Imla\'" && e.month === "Awal Tahun");\n      const newExamScores = [...target.examScores];\n      if (!hasBerhitungAwal) newExamScores.push({\n        id: genId(),\n        subject: "Berhitung",\n        value: b.berhitung,\n        month: "Awal Tahun"\n      });\n      if (!hasImlaAwal) newExamScores.push({\n        id: genId(),\n        subject: "Imla\'",\n        value: b.imla,\n        month: "Awal Tahun"\n      });\n      const newIbadah = [...target.ibadah, {\n        id: genId(),\n        date: "Awal Tahun",\n        value: b.ibadah\n      }];\n      const baseline = {\n        kelasAwal: b.kelasAwal,\n        rataRata: b.rataRata,\n        kelulusan: b.kelulusan,\n        ketKelulusan: b.ketKelulusan,\n        akselerasi: b.akselerasi,\n        ketAkselerasi: b.ketAkselerasi,\n        noAbsen: b.noAbsen,\n        kelasAkhir: "B15"\n      };\n      updates.push(db.doc("students/" + target.id).update({\n        examScores: newExamScores,\n        ibadah: newIbadah,\n        baseline\n      }));\n    });\n    Promise.all(updates).then(() => {\n      showToast(unmatched.length ? `${matched} santri terimpor. Tidak cocok: ${unmatched.join(", ")}` : `${matched} santri berhasil diimpor nilai awal tahunnya.`);\n    }).catch(() => showToast("Sebagian data gagal diimpor, coba lagi."));\n  }\n  function restoreBackup(parsed) {\n    const tasks = [];\n    parsed.students.forEach(s => {\n      const rest = Object.assign({}, s);\n      delete rest.id;\n      const docId = s.noDaftar || s.id || genId();\n      tasks.push(db.doc("students/" + docId).set(Object.assign({}, emptyStudentData(rest.name, rest.noDaftar), rest)));\n    });\n    tasks.push(db.doc("meta/config").set({\n      subjects: parsed.subjects || DEFAULT_SUBJECTS,\n      currentWeek: parsed.currentWeek || 1\n    }));\n    Promise.all(tasks).then(() => showToast(`Data dipulihkan: ${parsed.students.length} santri.`)).catch(() => showToast("Gagal memulihkan sebagian data."));\n  }\n  const withStatus = students.map(s => ({\n    ...s,\n    status: overallStatus(s)\n  }));\n  const counts = {\n    aman: 0,\n    perhatian: 0,\n    intervensi: 0\n  };\n  withStatus.forEach(s => counts[s.status]++);\n  const subjectAgg = {};\n  CORE_SUBJECTS.forEach(subj => {\n    const values = students.map(s => latestExam(s, subj)).filter(v => v !== null);\n    const green = values.filter(v => statusOf(v) === "green").length;\n    const yellow = values.filter(v => statusOf(v) === "yellow").length;\n    const red = values.filter(v => statusOf(v) === "red").length;\n    const avg = values.length ? Math.round(values.reduce((a, b) => a + b, 0) / values.length) : 0;\n    subjectAgg[subj] = {\n      green,\n      yellow,\n      red,\n      avg,\n      count: values.length\n    };\n  });\n  const gradReadiness = Math.round(CORE_SUBJECTS.reduce((a, s) => a + subjectAgg[s].avg, 0) / CORE_SUBJECTS.length);\n  const extraNames = [];\n  students.forEach(s => scoreList(s, false).forEach(r => {\n    if (!subjects.includes(r.subject) && !extraNames.includes(r.subject)) extraNames.push(r.subject);\n  }));\n  const perMapel = [...subjects, ...extraNames].map((subj, idx) => {\n    const rows = students.map(s => ({\n      id: s.id,\n      name: s.name,\n      value: latestScoreIn(s, subj, false)\n    })).filter(r => r.value !== null);\n    if (!rows.length) return null;\n    const avg = Math.round(rows.reduce((a, r) => a + r.value, 0) / rows.length);\n    const weak = rows.filter(r => r.value <= PERHATIAN_MAX).sort((a, b) => a.value - b.value);\n    return {\n      subj,\n      idx,\n      avg,\n      weak,\n      n: rows.length\n    };\n  }).filter(Boolean).sort((a, b) => b.weak.length - a.weak.length || a.idx - b.idx);\n  return /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      minHeight: "100vh",\n      background: PAPER,\n      fontFamily: "-apple-system, BlinkMacSystemFont, \'Segoe UI\', sans-serif",\n      color: TEXT\n    }\n  }, /*#__PURE__*/React.createElement("aside", {\n    style: {\n      width: 224,\n      background: INK,\n      color: "#EDEAE0",\n      flexShrink: 0,\n      padding: "22px 14px"\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      padding: "0 8px 20px",\n      borderBottom: "1px solid rgba(237,234,224,0.15)",\n      marginBottom: 12\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 17\n    }\n  }, "B15 Dashboard"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: "rgba(237,234,224,0.6)",\n      marginTop: 2\n    }\n  }, students.length, " / ", MAX_SANTRI, " santri"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 11,\n      color: "#9FD8B8",\n      marginTop: 8\n    }\n  }, "\\u25CF Tersambung ke database bersama")), /*#__PURE__*/React.createElement("nav", {\n    style: {\n      display: "flex",\n      flexDirection: "column",\n      gap: 2\n    }\n  }, NAV_ITEMS.map(item => {\n    const Icon = item.icon;\n    const active = view === item.key;\n    return /*#__PURE__*/React.createElement("button", {\n      key: item.key,\n      onClick: () => setView(item.key),\n      style: {\n        display: "flex",\n        alignItems: "center",\n        gap: 10,\n        padding: "9px 10px",\n        borderRadius: 7,\n        border: "none",\n        background: active ? INK_SOFT : "transparent",\n        color: active ? "#FFFFFF" : "rgba(237,234,224,0.75)",\n        fontSize: 13.5,\n        textAlign: "left",\n        cursor: "pointer"\n      }\n    }, /*#__PURE__*/React.createElement(Icon, {\n      size: 16,\n      strokeWidth: 1.8\n    }), item.label);\n  }))), /*#__PURE__*/React.createElement("main", {\n    style: {\n      flex: 1,\n      padding: "26px 32px",\n      maxWidth: 1000\n    }\n  }, view === "peringkat" && /*#__PURE__*/React.createElement(RankingPage, {\n    students: students,\n    onSelect: setSelectedId\n  }), view === "absen" && /*#__PURE__*/React.createElement(AbsenPage, {\n    students: students,\n    onSetAbsen: setAbsen,\n    onSelect: setSelectedId\n  }), view === "kelasMalam" && /*#__PURE__*/React.createElement(KelasMalamPage, {\n    students: students,\n    config: kelasConfig,\n    onSetConfig: setKelasConfig,\n    onToggle: toggleKelasMalam,\n    onSelect: setSelectedId\n  }), view === "setoran" && /*#__PURE__*/React.createElement(SetoranPage, {\n    students: students,\n    onAddEntry: addEntry,\n    onDeleteEntry: deleteEntry,\n    onSelect: setSelectedId,\n    pendingOf: (s, dk) => pendingTugas(s, dk, kelasConfig)\n  }), view === "dashboard" && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      margin: "0 0 16px"\n    }\n  }, "Kelas B15 \\xB7 Semester 2"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 12,\n      marginBottom: 24,\n      flexWrap: "wrap"\n    }\n  }, /*#__PURE__*/React.createElement(StatCard, {\n    label: "Total santri",\n    value: students.length\n  }), /*#__PURE__*/React.createElement(StatCard, {\n    label: "Aman",\n    value: counts.aman,\n    accent: GREEN\n  }), /*#__PURE__*/React.createElement(StatCard, {\n    label: "Perlu perhatian",\n    value: counts.perhatian,\n    accent: YELLOW\n  }), /*#__PURE__*/React.createElement(StatCard, {\n    label: "Perlu intervensi",\n    value: counts.intervensi,\n    accent: RED\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      margin: "-12px 0 24px",\n      maxWidth: 520\n    }\n  }, "Perlu perhatian = ada mapel bernilai ", PERHATIAN_MAX, " ke bawah. Perlu intervensi = ", INTERVENSI_MIN_COUNT, " mapel atau lebih bernilai ", PERHATIAN_MAX, " ke bawah."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      padding: 20,\n      maxWidth: 460\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      color: TEXT_MUTED,\n      marginBottom: 14\n    }\n  }, "Kesiapan kelulusan \\xB7 5 mapel inti"), CORE_SUBJECTS.map(subj => /*#__PURE__*/React.createElement("div", {\n    key: subj,\n    style: {\n      marginBottom: 12\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      justifyContent: "space-between",\n      fontSize: 13,\n      marginBottom: 4\n    }\n  }, /*#__PURE__*/React.createElement("span", null, labelOf(subj)), /*#__PURE__*/React.createElement("span", {\n    style: {\n      color: TEXT_MUTED\n    }\n  }, subjectAgg[subj].count ? `${subjectAgg[subj].avg}%` : "belum ada data")), /*#__PURE__*/React.createElement(ProgressBar, {\n    pct: subjectAgg[subj].avg,\n    color: GOLD\n  }))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      marginTop: 14,\n      paddingTop: 12,\n      borderTop: `1px solid ${BORDER}`,\n      fontSize: 13,\n      color: TEXT_MUTED\n    }\n  }, "Rata-rata kesiapan kelulusan kelas: ", /*#__PURE__*/React.createElement("strong", {\n    style: {\n      color: TEXT\n    }\n  }, gradReadiness, "%"))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      marginTop: 22\n    }\n  }, /*#__PURE__*/React.createElement(QuranPanel, {\n    students: students,\n    onSelect: setSelectedId\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      marginTop: 22\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      fontWeight: 500,\n      marginBottom: 4\n    }\n  }, "Perlu perhatian \\xB7 per mapel"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 10\n    }\n  }, "Santri bernilai ", PERHATIAN_MAX, " ke bawah. Mapel dengan santri paling banyak ada di urutan atas."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexDirection: "column",\n      gap: 12,\n      maxWidth: 460\n    }\n  }, perMapel.map(({\n    subj,\n    avg,\n    weak,\n    n\n  }) => /*#__PURE__*/React.createElement("div", {\n    key: subj,\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      padding: 16\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      justifyContent: "space-between",\n      fontSize: 13,\n      fontWeight: 500,\n      marginBottom: weak.length ? 10 : 0\n    }\n  }, /*#__PURE__*/React.createElement("span", null, labelOf(subj)), /*#__PURE__*/React.createElement("span", {\n    style: {\n      color: TEXT_MUTED,\n      fontWeight: 400\n    }\n  }, "rata-rata ", avg, " \\xB7 ", weak.length, " perlu perhatian")), weak.length ? /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexWrap: "wrap",\n      gap: 6\n    }\n  }, weak.map(r => /*#__PURE__*/React.createElement("span", {\n    key: r.id,\n    onClick: () => setSelectedId(r.id),\n    style: {\n      fontSize: 12,\n      background: RED_BG,\n      color: RED,\n      borderRadius: 6,\n      padding: "4px 9px",\n      cursor: "pointer"\n    }\n  }, r.name, " \\xB7 ", r.value))) : /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: GREEN\n    }\n  }, "Tidak ada santri bernilai ", PERHATIAN_MAX, " ke bawah di mapel ini."))), !perMapel.length && /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED\n    }\n  }, "Belum ada nilai yang diinput.")))), view === "santri" && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 16\n    }\n  }, "Data Santri"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 8,\n      marginBottom: 10,\n      maxWidth: 420\n    }\n  }, /*#__PURE__*/React.createElement("input", {\n    value: newName,\n    onChange: e => setNewName(e.target.value),\n    onKeyDown: e => e.key === "Enter" && addStudent(),\n    placeholder: "Nama santri baru",\n    style: {\n      ...inputStyle,\n      flex: 1\n    }\n  }), /*#__PURE__*/React.createElement("button", {\n    onClick: addStudent,\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 6,\n      background: INK,\n      color: "#fff",\n      border: "none",\n      borderRadius: 6,\n      padding: "0 14px",\n      cursor: "pointer",\n      fontSize: 13\n    }\n  }, /*#__PURE__*/React.createElement(Plus, {\n    size: 14\n  }), " Tambah")), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 8,\n      marginBottom: 16,\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 8,\n      padding: "8px 12px",\n      maxWidth: 300\n    }\n  }, /*#__PURE__*/React.createElement(Search, {\n    size: 15,\n    color: TEXT_MUTED\n  }), /*#__PURE__*/React.createElement("input", {\n    value: searchQuery,\n    onChange: e => setSearchQuery(e.target.value),\n    placeholder: "Cari nama atau no. daftar santri",\n    style: {\n      border: "none",\n      outline: "none",\n      fontSize: 13,\n      flex: 1,\n      background: "transparent"\n    }\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      overflow: "hidden"\n    }\n  }, /*#__PURE__*/React.createElement("table", {\n    style: {\n      width: "100%",\n      borderCollapse: "collapse",\n      fontSize: 13\n    }\n  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {\n    style: {\n      background: PAPER,\n      textAlign: "left"\n    }\n  }, /*#__PURE__*/React.createElement("th", {\n    style: {\n      padding: "10px 14px",\n      fontWeight: 500,\n      color: TEXT_MUTED\n    }\n  }, "No"), /*#__PURE__*/React.createElement("th", {\n    style: {\n      padding: "10px 14px",\n      fontWeight: 500,\n      color: TEXT_MUTED\n    }\n  }, "Nama"), /*#__PURE__*/React.createElement("th", {\n    style: {\n      padding: "10px 8px",\n      fontWeight: 500,\n      color: TEXT_MUTED,\n      textAlign: "center"\n    }\n  }, "Status"), /*#__PURE__*/React.createElement("th", {\n    style: {\n      padding: "10px 8px",\n      fontWeight: 500,\n      color: TEXT_MUTED,\n      textAlign: "center"\n    }\n  }, "Izin Piket"), /*#__PURE__*/React.createElement("th", {\n    style: {\n      padding: "10px 14px"\n    }\n  }))), /*#__PURE__*/React.createElement("tbody", null, withStatus.filter(s => s.name.toLowerCase().includes(searchQuery.toLowerCase()) || (s.noDaftar || "").toLowerCase().includes(searchQuery.toLowerCase())).map(s => /*#__PURE__*/React.createElement("tr", {\n    key: s.id,\n    style: {\n      borderTop: `1px solid ${BORDER}`\n    }\n  }, /*#__PURE__*/React.createElement("td", {\n    onClick: () => setSelectedId(s.id),\n    style: {\n      padding: "10px 14px",\n      color: TEXT_MUTED,\n      cursor: "pointer"\n    }\n  }, s.noDaftar || "-"), /*#__PURE__*/React.createElement("td", {\n    onClick: () => setSelectedId(s.id),\n    style: {\n      padding: "10px 14px",\n      fontWeight: 500,\n      cursor: "pointer"\n    }\n  }, s.name), /*#__PURE__*/React.createElement("td", {\n    onClick: () => setSelectedId(s.id),\n    style: {\n      padding: "10px 8px",\n      textAlign: "center",\n      cursor: "pointer"\n    }\n  }, /*#__PURE__*/React.createElement(Dot, {\n    status: s.status === "aman" ? "green" : s.status === "perhatian" ? "yellow" : "red"\n  })), /*#__PURE__*/React.createElement("td", {\n    onClick: () => setSelectedId(s.id),\n    style: {\n      padding: "10px 8px",\n      textAlign: "center",\n      cursor: "pointer",\n      color: s.izinPiket.length > 3 ? RED : TEXT_MUTED\n    }\n  }, s.izinPiket.length, "\\xD7"), /*#__PURE__*/React.createElement("td", {\n    style: {\n      padding: "10px 14px",\n      textAlign: "right"\n    }\n  }, pendingDeleteId === s.id ? /*#__PURE__*/React.createElement(ConfirmDelete, {\n    onConfirm: () => deleteStudent(s.id),\n    onCancel: () => setPendingDeleteId(null)\n  }) : /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      justifyContent: "flex-end",\n      gap: 10\n    }\n  }, /*#__PURE__*/React.createElement("button", {\n    onClick: () => setSelectedId(s.id),\n    style: {\n      border: "none",\n      background: "transparent",\n      cursor: "pointer",\n      color: TEXT_MUTED,\n      display: "flex"\n    }\n  }, /*#__PURE__*/React.createElement(ChevronRight, {\n    size: 15\n  })), /*#__PURE__*/React.createElement(IconBtn, {\n    onClick: () => setPendingDeleteId(s.id),\n    title: "Hapus santri"\n  }))))), !students.length && /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {\n    colSpan: 3,\n    style: {\n      padding: 20,\n      color: TEXT_MUTED,\n      textAlign: "center"\n    }\n  }, "Belum ada santri. Tambahkan nama di atas.")))))), view === "inputMassal" && /*#__PURE__*/React.createElement(BulkRegularInput, {\n    subjects: subjects,\n    students: students,\n    onSave: addEntry,\n    showToast: showToast\n  }), view === "ujianMassal" && /*#__PURE__*/React.createElement(BulkExamInput, {\n    students: students,\n    onSaveExam: saveExamScore,\n    showToast: showToast,\n    quickImports: [...UTS_BATCHES.map(b => ({\n      title: b.title,\n      desc: b.desc,\n      audit: auditBatch(students, b),\n      onClick: () => importUTSBatch(b)\n    }))]\n  }), view === "mapel" && /*#__PURE__*/React.createElement(MapelPage, {\n    subjects: subjects,\n    students: students,\n    renameSubject: renameSubject\n  }), view === "roadmap" && /*#__PURE__*/React.createElement(RoadmapPage, {\n    students: students,\n    currentWeek: currentWeek,\n    setCurrentWeek: setCurrentWeek,\n    onSelect: setSelectedId\n  }), view === "backup" && /*#__PURE__*/React.createElement(BackupPage, {\n    students: students,\n    subjects: subjects,\n    currentWeek: currentWeek,\n    showToast: showToast,\n    onImportBaseline: importBaselineData,\n    onRestoreBackup: restoreBackup\n  }), view === "analitik" && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 16\n    }\n  }, "Analitik kelas"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexDirection: "column",\n      gap: 16,\n      maxWidth: 520\n    }\n  }, CORE_SUBJECTS.map(subj => {\n    const a = subjectAgg[subj];\n    const total = a.green + a.yellow + a.red;\n    return /*#__PURE__*/React.createElement("div", {\n      key: subj,\n      style: {\n        background: CARD,\n        border: `1px solid ${BORDER}`,\n        borderRadius: 10,\n        padding: 18\n      }\n    }, /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 14,\n        fontWeight: 500,\n        marginBottom: 10\n      }\n    }, subj), total ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        height: 10,\n        borderRadius: 6,\n        overflow: "hidden"\n      }\n    }, /*#__PURE__*/React.createElement("div", {\n      style: {\n        width: `${a.green / total * 100}%`,\n        background: GREEN\n      }\n    }), /*#__PURE__*/React.createElement("div", {\n      style: {\n        width: `${a.red / total * 100}%`,\n        background: RED\n      }\n    })), /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        gap: 16,\n        fontSize: 12,\n        color: TEXT_MUTED,\n        marginTop: 8\n      }\n    }, /*#__PURE__*/React.createElement("span", null, a.green, " aman"), /*#__PURE__*/React.createElement("span", null, a.red, " perlu perhatian (", PERHATIAN_MAX, " ke bawah)"))) : /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 12,\n        color: TEXT_MUTED\n      }\n    }, "Belum ada data ujian bulanan."));\n  })))), selected && /*#__PURE__*/React.createElement(StudentProfile, {\n    student: selected,\n    subjects: subjects,\n    onClose: () => setSelectedId(null),\n    onAddEntry: addEntry,\n    onDeleteEntry: deleteEntry\n  }), /*#__PURE__*/React.createElement(Toast, {\n    message: toast\n  }));\n}\nfunction QuranPanel({\n  students,\n  onSelect\n}) {\n  const [showAll, setShowAll] = useState(false);\n  const rows = students.map(s => ({\n    id: s.id,\n    name: s.name,\n    tulis: latestScoreIn(s, "Al-Qur\'an (tulis)", false),\n    lisan: latestScoreIn(s, "Al-Qur\'an", false)\n  })).filter(r => r.tulis !== null || r.lisan !== null);\n  const stat = key => {\n    const vals = rows.map(r => r[key]).filter(v => v !== null);\n    if (!vals.length) return null;\n    return {\n      avg: vals.reduce((a, v) => a + v, 0) / vals.length,\n      weak: vals.filter(v => v <= PERHATIAN_MAX).length,\n      max: Math.max(...vals),\n      min: Math.min(...vals),\n      n: vals.length\n    };\n  };\n  const cards = [{\n    key: "tulis",\n    label: "Al-Qur\'an tulis",\n    note: ""\n  }, {\n    key: "lisan",\n    label: "Al-Qur\'an lisan (syafahi)",\n    note: "Acuan Al-Qur\'an kelulusan"\n  }];\n  const lowest = r => Math.min(r.tulis === null ? 999 : r.tulis, r.lisan === null ? 999 : r.lisan);\n  const isWeak = v => v !== null && v <= PERHATIAN_MAX;\n  const sorted = [...rows].sort((a, b) => lowest(a) - lowest(b) || a.name.localeCompare(b.name));\n  const attention = sorted.filter(r => isWeak(r.tulis) || isWeak(r.lisan));\n  const shown = showAll ? sorted : attention;\n  const cell = v => /*#__PURE__*/React.createElement("td", {\n    style: {\n      padding: "8px 12px",\n      textAlign: "center"\n    }\n  }, v === null ? /*#__PURE__*/React.createElement("span", {\n    style: {\n      color: TEXT_MUTED\n    }\n  }, "-") : /*#__PURE__*/React.createElement("span", {\n    style: {\n      display: "inline-block",\n      minWidth: 34,\n      padding: "2px 8px",\n      borderRadius: 6,\n      fontWeight: 600,\n      fontSize: 12.5,\n      background: v <= PERHATIAN_MAX ? RED_BG : GREEN_BG,\n      color: v <= PERHATIAN_MAX ? RED : GREEN\n    }\n  }, v));\n  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      fontWeight: 500,\n      marginBottom: 4\n    }\n  }, "Al-Qur\'an \\xB7 tulis dan lisan"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 10\n    }\n  }, "Nilai terakhir tiap santri. Merah = ", PERHATIAN_MAX, " ke bawah."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 12,\n      flexWrap: "wrap",\n      marginBottom: 12,\n      maxWidth: 460\n    }\n  }, cards.map(c => {\n    const st = stat(c.key);\n    return /*#__PURE__*/React.createElement("div", {\n      key: c.key,\n      style: {\n        background: CARD,\n        border: `1px solid ${BORDER}`,\n        borderRadius: 10,\n        padding: "14px 16px",\n        flex: "1 1 190px"\n      }\n    }, /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 12,\n        color: TEXT_MUTED,\n        marginBottom: 6\n      }\n    }, c.label), st ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontFamily: "Georgia, serif",\n        fontSize: 28,\n        lineHeight: 1\n      }\n    }, st.avg.toFixed(1).replace(".", ",")), /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 12,\n        color: TEXT_MUTED,\n        marginTop: 6\n      }\n    }, "rata-rata kelas (", st.n, " santri)"), /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 12,\n        marginTop: 4,\n        color: st.weak ? RED : GREEN\n      }\n    }, st.weak, " santri ", PERHATIAN_MAX, " ke bawah"), /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 12,\n        color: TEXT_MUTED,\n        marginTop: 2\n      }\n    }, "tertinggi ", st.max, " \\xB7 terendah ", st.min), c.note && /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 11,\n        color: GOLD,\n        marginTop: 6\n      }\n    }, c.note)) : /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 12,\n        color: TEXT_MUTED\n      }\n    }, "Belum ada nilai."));\n  })), rows.length > 0 && /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      overflow: "hidden",\n      maxWidth: 460\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      padding: "10px 14px",\n      fontSize: 12,\n      color: TEXT_MUTED,\n      background: PAPER\n    }\n  }, showAll ? `Semua santri (${rows.length}), nilai terendah di atas` : `${attention.length} santri bernilai ${PERHATIAN_MAX} ke bawah di tulis atau lisan`), /*#__PURE__*/React.createElement("table", {\n    style: {\n      width: "100%",\n      borderCollapse: "collapse",\n      fontSize: 13\n    }\n  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {\n    style: {\n      textAlign: "left",\n      borderTop: `1px solid ${BORDER}`\n    }\n  }, /*#__PURE__*/React.createElement("th", {\n    style: {\n      padding: "8px 14px",\n      fontWeight: 500,\n      color: TEXT_MUTED\n    }\n  }, "Nama"), /*#__PURE__*/React.createElement("th", {\n    style: {\n      padding: "8px 12px",\n      fontWeight: 500,\n      color: TEXT_MUTED,\n      textAlign: "center"\n    }\n  }, "Tulis"), /*#__PURE__*/React.createElement("th", {\n    style: {\n      padding: "8px 12px",\n      fontWeight: 500,\n      color: TEXT_MUTED,\n      textAlign: "center"\n    }\n  }, "Lisan"))), /*#__PURE__*/React.createElement("tbody", null, shown.map(r => /*#__PURE__*/React.createElement("tr", {\n    key: r.id,\n    onClick: () => onSelect(r.id),\n    style: {\n      borderTop: `1px solid ${BORDER}`,\n      cursor: "pointer"\n    }\n  }, /*#__PURE__*/React.createElement("td", {\n    style: {\n      padding: "8px 14px",\n      fontWeight: 500\n    }\n  }, r.name), cell(r.tulis), cell(r.lisan))), !shown.length && /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {\n    colSpan: 3,\n    style: {\n      padding: 16,\n      textAlign: "center",\n      color: GREEN,\n      fontSize: 12\n    }\n  }, "Tidak ada santri bernilai ", PERHATIAN_MAX, " ke bawah.")))), /*#__PURE__*/React.createElement("button", {\n    onClick: () => setShowAll(!showAll),\n    style: {\n      width: "100%",\n      border: "none",\n      borderTop: `1px solid ${BORDER}`,\n      background: PAPER,\n      color: INK,\n      padding: "10px 14px",\n      fontSize: 12.5,\n      cursor: "pointer"\n    }\n  }, showAll ? "Tampilkan yang perlu perhatian saja" : `Tampilkan semua ${rows.length} santri`)));\n}\nfunction RankingPage({\n  students,\n  onSelect\n}) {\n  const [scope, setScope] = useState("all");\n  const [sortBy, setSortBy] = useState("total");\n  const [query, setQuery] = useState("");\n  const base = students.map(s => {\n    const list = scoreList(s, scope === "uts");\n    const total = list.reduce((a, r) => a + r.value, 0);\n    return {\n      id: s.id,\n      name: s.name,\n      noDaftar: s.noDaftar,\n      count: list.length,\n      total,\n      avg: list.length ? total / list.length : 0\n    };\n  });\n  const keyOf = r => sortBy === "avg" ? r.avg : r.total;\n  const sorted = [...base].sort((a, b) => (b.count > 0) - (a.count > 0) || keyOf(b) - keyOf(a) || b.total - a.total || a.name.localeCompare(b.name));\n  const scored = sorted.filter(r => r.count > 0);\n  const ranked = sorted.map(r => ({\n    ...r,\n    rank: r.count ? 1 + scored.filter(o => keyOf(o) > keyOf(r)).length : null\n  }));\n  const classTotal = scored.reduce((a, r) => a + r.total, 0);\n  const totalCount = scored.reduce((a, r) => a + r.count, 0);\n  const top = ranked.length && ranked[0].count ? ranked[0] : null;\n  const q = query.toLowerCase();\n  const visible = ranked.filter(r => r.name.toLowerCase().includes(q) || (r.noDaftar || "").includes(q));\n  const fmt = n => n.toLocaleString("id-ID");\n  const seg = active => ({\n    border: `1px solid ${active ? INK : BORDER}`,\n    background: active ? INK : CARD,\n    color: active ? "#fff" : TEXT,\n    borderRadius: 6,\n    padding: "6px 12px",\n    fontSize: 12.5,\n    cursor: "pointer"\n  });\n  const th = {\n    padding: "10px 12px",\n    fontWeight: 500,\n    color: TEXT_MUTED\n  };\n  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 6\n    }\n  }, "Peringkat nilai"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 16,\n      maxWidth: 540\n    }\n  }, "Total = jumlah nilai terakhir tiap mapel yang sudah diinput. Kalau ada santri yang belum punya nilai di satu mapel (misal sakit), cek kolom Mapel atau urutkan berdasarkan Rata-rata biar adil."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 20,\n      flexWrap: "wrap",\n      marginBottom: 16\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 6,\n      alignItems: "center"\n    }\n  }, /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED\n    }\n  }, "Nilai"), /*#__PURE__*/React.createElement("button", {\n    onClick: () => setScope("all"),\n    style: seg(scope === "all")\n  }, "Semua nilai"), /*#__PURE__*/React.createElement("button", {\n    onClick: () => setScope("uts"),\n    style: seg(scope === "uts")\n  }, "UTS saja")), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 6,\n      alignItems: "center"\n    }\n  }, /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED\n    }\n  }, "Urutkan"), /*#__PURE__*/React.createElement("button", {\n    onClick: () => setSortBy("total"),\n    style: seg(sortBy === "total")\n  }, "Total"), /*#__PURE__*/React.createElement("button", {\n    onClick: () => setSortBy("avg"),\n    style: seg(sortBy === "avg")\n  }, "Rata-rata"))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 12,\n      marginBottom: 14,\n      flexWrap: "wrap"\n    }\n  }, /*#__PURE__*/React.createElement(StatCard, {\n    label: "Santri dinilai",\n    value: scored.length\n  }), /*#__PURE__*/React.createElement(StatCard, {\n    label: "Total seluruh kelas",\n    value: fmt(classTotal),\n    accent: GOLD\n  }), /*#__PURE__*/React.createElement(StatCard, {\n    label: "Rata-rata total / santri",\n    value: scored.length ? fmt(Math.round(classTotal / scored.length)) : 0\n  })), top && /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: GOLD_BG,\n      borderRadius: 10,\n      padding: "12px 16px",\n      marginBottom: 16,\n      maxWidth: 620,\n      fontSize: 13,\n      color: "#5A4415"\n    }\n  }, "Peringkat 1: ", /*#__PURE__*/React.createElement("strong", null, top.name), " \\xB7 total ", fmt(top.total), " \\xB7 rata-rata ", top.avg.toFixed(1).replace(".", ","), " dari ", top.count, " mapel"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 8,\n      marginBottom: 16,\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 8,\n      padding: "8px 12px",\n      maxWidth: 300\n    }\n  }, /*#__PURE__*/React.createElement(Search, {\n    size: 15,\n    color: TEXT_MUTED\n  }), /*#__PURE__*/React.createElement("input", {\n    value: query,\n    onChange: e => setQuery(e.target.value),\n    placeholder: "Cari nama atau no. daftar",\n    style: {\n      border: "none",\n      outline: "none",\n      fontSize: 13,\n      flex: 1,\n      background: "transparent"\n    }\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      overflow: "hidden",\n      maxWidth: 620\n    }\n  }, /*#__PURE__*/React.createElement("table", {\n    style: {\n      width: "100%",\n      borderCollapse: "collapse",\n      fontSize: 13\n    }\n  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {\n    style: {\n      background: PAPER,\n      textAlign: "left"\n    }\n  }, /*#__PURE__*/React.createElement("th", {\n    style: th\n  }, "#"), /*#__PURE__*/React.createElement("th", {\n    style: th\n  }, "Nama"), /*#__PURE__*/React.createElement("th", {\n    style: {\n      ...th,\n      textAlign: "center"\n    }\n  }, "Mapel"), /*#__PURE__*/React.createElement("th", {\n    style: {\n      ...th,\n      textAlign: "right"\n    }\n  }, "Total"), /*#__PURE__*/React.createElement("th", {\n    style: {\n      ...th,\n      textAlign: "right"\n    }\n  }, "Rata-rata"))), /*#__PURE__*/React.createElement("tbody", null, visible.map(r => /*#__PURE__*/React.createElement("tr", {\n    key: r.id,\n    onClick: () => onSelect(r.id),\n    style: {\n      borderTop: `1px solid ${BORDER}`,\n      cursor: "pointer",\n      background: r.rank && r.rank <= 3 ? "#FBF6EA" : "transparent"\n    }\n  }, /*#__PURE__*/React.createElement("td", {\n    style: {\n      padding: "9px 12px"\n    }\n  }, r.rank ? /*#__PURE__*/React.createElement("span", {\n    style: {\n      display: "inline-flex",\n      alignItems: "center",\n      justifyContent: "center",\n      width: 24,\n      height: 24,\n      borderRadius: 12,\n      fontSize: 12,\n      fontWeight: 600,\n      background: r.rank <= 3 ? GOLD : "#EFEDE5",\n      color: r.rank <= 3 ? "#fff" : TEXT_MUTED\n    }\n  }, r.rank) : "-"), /*#__PURE__*/React.createElement("td", {\n    style: {\n      padding: "9px 12px",\n      fontWeight: 500\n    }\n  }, r.name), /*#__PURE__*/React.createElement("td", {\n    style: {\n      padding: "9px 12px",\n      textAlign: "center",\n      color: TEXT_MUTED\n    }\n  }, r.count), /*#__PURE__*/React.createElement("td", {\n    style: {\n      padding: "9px 12px",\n      textAlign: "right",\n      fontWeight: 600\n    }\n  }, r.count ? fmt(r.total) : "-"), /*#__PURE__*/React.createElement("td", {\n    style: {\n      padding: "9px 12px",\n      textAlign: "right",\n      color: TEXT_MUTED\n    }\n  }, r.count ? r.avg.toFixed(1).replace(".", ",") : "-"))), !visible.length && /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {\n    colSpan: 5,\n    style: {\n      padding: 20,\n      textAlign: "center",\n      color: TEXT_MUTED\n    }\n  }, students.length ? "Tidak ada nama yang cocok." : "Belum ada santri."))), /*#__PURE__*/React.createElement("tfoot", null, /*#__PURE__*/React.createElement("tr", {\n    style: {\n      borderTop: `2px solid ${BORDER}`,\n      background: PAPER,\n      fontWeight: 600\n    }\n  }, /*#__PURE__*/React.createElement("td", {\n    colSpan: 3,\n    style: {\n      padding: "10px 12px"\n    }\n  }, "Total seluruh kelas (", scored.length, " santri)"), /*#__PURE__*/React.createElement("td", {\n    style: {\n      padding: "10px 12px",\n      textAlign: "right"\n    }\n  }, fmt(classTotal)), /*#__PURE__*/React.createElement("td", {\n    style: {\n      padding: "10px 12px",\n      textAlign: "right",\n      color: TEXT_MUTED\n    }\n  }, totalCount ? (classTotal / totalCount).toFixed(1).replace(".", ",") : "-"))))));\n}\nfunction KelasMalamPage({\n  students,\n  config,\n  onSetConfig,\n  onToggle,\n  onSelect\n}) {\n  const [dateKey, setDateKey] = useState(() => new Date().toISOString().slice(0, 10));\n  const [query, setQuery] = useState("");\n  const [drafts, setDrafts] = useState({});\n  const batas = config.kelasMalamBatas;\n  const q = query.toLowerCase();\n  const doneOf = (s, subject) => (s.kelasMalam || []).some(e => e.dateKey === dateKey && e.subject === subject);\n  const sections = KELAS_MALAM_SUBJECTS.map(def => {\n    const key = tugasKey(dateKey, def);\n    const saved = (config.tugasMalam || {})[key] || "";\n    const members = kelasMalamMembers(students, def.subject, batas);\n    return {\n      def,\n      key,\n      saved,\n      active: saved.trim() !== "",\n      members,\n      doneCount: members.filter(m => doneOf(m.student, def.subject)).length\n    };\n  });\n  const memberIds = {};\n  const kenaIds = {};\n  sections.forEach(sec => sec.members.forEach(m => {\n    memberIds[m.student.id] = true;\n    if (sec.active) kenaIds[m.student.id] = true;\n  }));\n  const kena = students.filter(s => kenaIds[s.id]).map(s => ({\n    s,\n    pending: pendingTugas(s, dateKey, config)\n  }));\n  const belum = kena.filter(r => r.pending.length > 0);\n  function saveTugas(sec) {\n    const text = (drafts[sec.key] !== undefined ? drafts[sec.key] : sec.saved).trim();\n    onSetConfig({\n      tugasMalam: {\n        ...(config.tugasMalam || {}),\n        [sec.key]: text\n      }\n    });\n    setDrafts(d => {\n      const n = {\n        ...d\n      };\n      delete n[sec.key];\n      return n;\n    });\n  }\n  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 6\n    }\n  }, "Kelas malam \\xB7 mapel kelulusan"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 16,\n      maxWidth: 560\n    }\n  }, "Santri yang nilainya ", batas, " ke bawah di Berhitung, Imla\', atau Al-Qur\'an (lisan) masuk kelas malam mapel itu. Tiap malam ada 1 tugas per mapel yang wajib diselesaikan sebelum pulang. Tugas baru berlaku setelah teksnya diisi."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 16,\n      marginBottom: 14,\n      flexWrap: "wrap"\n    }\n  }, /*#__PURE__*/React.createElement("input", {\n    type: "date",\n    value: dateKey,\n    onChange: e => setDateKey(e.target.value),\n    style: inputStyle\n  }), /*#__PURE__*/React.createElement("label", {\n    style: {\n      fontSize: 12.5,\n      color: TEXT_MUTED,\n      display: "flex",\n      alignItems: "center",\n      gap: 6\n    }\n  }, "Masuk kelas malam jika nilai", /*#__PURE__*/React.createElement("select", {\n    value: batas,\n    onChange: e => onSetConfig({\n      kelasMalamBatas: Number(e.target.value)\n    }),\n    style: {\n      ...inputStyle,\n      padding: "5px 8px"\n    }\n  }, [40, 45, 50, 55, 60].map(v => /*#__PURE__*/React.createElement("option", {\n    key: v,\n    value: v\n  }, v, " ke bawah"))))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 12,\n      marginBottom: 16,\n      flexWrap: "wrap"\n    }\n  }, /*#__PURE__*/React.createElement(StatCard, {\n    label: "Masuk kelas malam",\n    value: Object.keys(memberIds).length\n  }), /*#__PURE__*/React.createElement(StatCard, {\n    label: "Wajib tugas hari ini",\n    value: kena.length\n  }), /*#__PURE__*/React.createElement(StatCard, {\n    label: "Tugas lengkap",\n    value: kena.length - belum.length,\n    accent: GREEN\n  }), /*#__PURE__*/React.createElement(StatCard, {\n    label: "Belum selesai",\n    value: belum.length,\n    accent: RED\n  })), belum.length > 0 && /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: RED_BG,\n      borderRadius: 10,\n      padding: 14,\n      marginBottom: 16,\n      maxWidth: 560\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: RED,\n      fontWeight: 600,\n      marginBottom: 8\n    }\n  }, "Belum boleh pulang, tugas belum selesai (", belum.length, ")"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexWrap: "wrap",\n      gap: 6\n    }\n  }, belum.map(r => /*#__PURE__*/React.createElement("span", {\n    key: r.s.id,\n    onClick: () => onSelect(r.s.id),\n    style: {\n      fontSize: 12,\n      background: "#fff",\n      color: RED,\n      borderRadius: 6,\n      padding: "4px 9px",\n      cursor: "pointer"\n    }\n  }, r.s.name, " \\xB7 ", r.pending.join(", "))))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 8,\n      marginBottom: 16,\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 8,\n      padding: "8px 12px",\n      maxWidth: 300\n    }\n  }, /*#__PURE__*/React.createElement(Search, {\n    size: 15,\n    color: TEXT_MUTED\n  }), /*#__PURE__*/React.createElement("input", {\n    value: query,\n    onChange: e => setQuery(e.target.value),\n    placeholder: "Cari nama santri",\n    style: {\n      border: "none",\n      outline: "none",\n      fontSize: 13,\n      flex: 1,\n      background: "transparent"\n    }\n  })), sections.map(sec => {\n    const draft = drafts[sec.key];\n    const changed = draft !== undefined && draft.trim() !== sec.saved.trim();\n    const shown = sec.members.filter(m => m.student.name.toLowerCase().includes(q));\n    return /*#__PURE__*/React.createElement("div", {\n      key: sec.def.code,\n      style: {\n        background: CARD,\n        border: `1px solid ${BORDER}`,\n        borderRadius: 10,\n        padding: 16,\n        marginBottom: 14,\n        maxWidth: 560\n      }\n    }, /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        justifyContent: "space-between",\n        alignItems: "baseline"\n      }\n    }, /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 14,\n        fontWeight: 600\n      }\n    }, sec.def.label), /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 12,\n        color: TEXT_MUTED\n      }\n    }, sec.members.length, " santri \\xB7 ", sec.doneCount, " selesai")), /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        gap: 6,\n        margin: "10px 0 6px"\n      }\n    }, /*#__PURE__*/React.createElement("input", {\n      value: draft !== undefined ? draft : sec.saved,\n      onChange: e => setDrafts(d => ({\n        ...d,\n        [sec.key]: e.target.value\n      })),\n      onKeyDown: e => e.key === "Enter" && changed && saveTugas(sec),\n      placeholder: "Tugas malam ini, mis. soal no. 5-10 hal. 12",\n      style: {\n        ...inputStyle,\n        flex: 1,\n        fontSize: 12.5\n      }\n    }), /*#__PURE__*/React.createElement("button", {\n      onClick: () => saveTugas(sec),\n      disabled: !changed,\n      style: {\n        background: changed ? INK : "#EFEDE5",\n        color: changed ? "#fff" : TEXT_MUTED,\n        border: "none",\n        borderRadius: 6,\n        padding: "0 12px",\n        fontSize: 12,\n        cursor: changed ? "pointer" : "default"\n      }\n    }, "Simpan tugas")), /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 11.5,\n        color: sec.active ? GREEN : YELLOW,\n        marginBottom: 10\n      }\n    }, sec.active ? "Tugas aktif. Centang santri yang sudah selesai." : "Belum ada tugas hari ini. Isi dulu supaya centang dan syarat pulang berlaku."), shown.map(m => {\n      const done = doneOf(m.student, sec.def.subject);\n      return /*#__PURE__*/React.createElement("div", {\n        key: m.student.id,\n        style: {\n          display: "flex",\n          alignItems: "center",\n          gap: 10,\n          padding: "7px 0",\n          borderTop: `1px solid ${BORDER}`\n        }\n      }, /*#__PURE__*/React.createElement("span", {\n        onClick: () => onSelect(m.student.id),\n        style: {\n          flex: 1,\n          fontSize: 13,\n          cursor: "pointer"\n        }\n      }, m.student.name), /*#__PURE__*/React.createElement("span", {\n        style: {\n          fontSize: 12,\n          background: RED_BG,\n          color: RED,\n          borderRadius: 6,\n          padding: "2px 8px"\n        }\n      }, m.value), /*#__PURE__*/React.createElement("button", {\n        onClick: () => onToggle(m.student.id, dateKey, sec.def.subject),\n        disabled: !sec.active,\n        style: {\n          minWidth: 82,\n          border: "none",\n          borderRadius: 6,\n          padding: "5px 10px",\n          fontSize: 12,\n          cursor: sec.active ? "pointer" : "not-allowed",\n          opacity: sec.active ? 1 : 0.45,\n          background: done ? GREEN : RED_BG,\n          color: done ? "#fff" : RED\n        }\n      }, done ? "Selesai \\u2713" : "Belum"));\n    }), !sec.members.length && /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 12,\n        color: GREEN\n      }\n    }, "Tidak ada santri bernilai ", batas, " ke bawah di mapel ini."), sec.members.length > 0 && !shown.length && /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 12,\n        color: TEXT_MUTED\n      }\n    }, "Tidak ada nama yang cocok."));\n  }));\n}\nfunction AbsenPage({\n  students,\n  onSetAbsen,\n  onSelect\n}) {\n  const [dateKey, setDateKey] = useState(() => new Date().toISOString().slice(0, 10));\n  const [query, setQuery] = useState("");\n  const [notes, setNotes] = useState({});\n  function entryFor(student) {\n    return (student.absensi || []).find(e => e.dateKey === dateKey);\n  }\n  const hadirList = students.filter(s => {\n    const e = entryFor(s);\n    return e && e.status === "Hadir";\n  });\n  const tidakHadirList = students.filter(s => {\n    const e = entryFor(s);\n    return e && e.status === "Tidak Hadir";\n  });\n  const belumCount = students.length - hadirList.length - tidakHadirList.length;\n  const filtered = students.filter(s => s.name.toLowerCase().includes(query.toLowerCase()));\n  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 6\n    }\n  }, "Absen harian"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 16\n    }\n  }, "Tandai kehadiran tiap santri per hari."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 14,\n      marginBottom: 14,\n      flexWrap: "wrap"\n    }\n  }, /*#__PURE__*/React.createElement("input", {\n    type: "date",\n    value: dateKey,\n    onChange: e => setDateKey(e.target.value),\n    style: inputStyle\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 12,\n      marginBottom: 18,\n      flexWrap: "wrap"\n    }\n  }, /*#__PURE__*/React.createElement(StatCard, {\n    label: "Hadir",\n    value: hadirList.length,\n    accent: GREEN\n  }), /*#__PURE__*/React.createElement(StatCard, {\n    label: "Tidak hadir",\n    value: tidakHadirList.length,\n    accent: RED\n  }), /*#__PURE__*/React.createElement(StatCard, {\n    label: "Belum ditandai",\n    value: belumCount\n  })), tidakHadirList.length > 0 && /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: RED_BG,\n      borderRadius: 10,\n      padding: 14,\n      marginBottom: 18,\n      maxWidth: 560\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: RED,\n      fontWeight: 600,\n      marginBottom: 8\n    }\n  }, "Tidak hadir hari ini"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexWrap: "wrap",\n      gap: 6\n    }\n  }, tidakHadirList.map(s => {\n    const e = entryFor(s);\n    return /*#__PURE__*/React.createElement("span", {\n      key: s.id,\n      onClick: () => onSelect(s.id),\n      style: {\n        fontSize: 12,\n        background: "#fff",\n        color: RED,\n        borderRadius: 6,\n        padding: "4px 9px",\n        cursor: "pointer"\n      }\n    }, s.name, e.keterangan ? ` \\u00b7 ${e.keterangan}` : "");\n  }))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 8,\n      marginBottom: 16,\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 8,\n      padding: "8px 12px",\n      maxWidth: 300\n    }\n  }, /*#__PURE__*/React.createElement(Search, {\n    size: 15,\n    color: TEXT_MUTED\n  }), /*#__PURE__*/React.createElement("input", {\n    value: query,\n    onChange: e => setQuery(e.target.value),\n    placeholder: "Cari nama santri",\n    style: {\n      border: "none",\n      outline: "none",\n      fontSize: 13,\n      flex: 1,\n      background: "transparent"\n    }\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexDirection: "column",\n      gap: 8,\n      maxWidth: 560\n    }\n  }, filtered.map(s => {\n    const e = entryFor(s);\n    const status = e ? e.status : null;\n    return /*#__PURE__*/React.createElement("div", {\n      key: s.id,\n      style: {\n        background: CARD,\n        border: `1px solid ${BORDER}`,\n        borderRadius: 10,\n        padding: "10px 14px",\n        display: "flex",\n        alignItems: "center",\n        gap: 10,\n        flexWrap: "wrap"\n      }\n    }, /*#__PURE__*/React.createElement("span", {\n      onClick: () => onSelect(s.id),\n      style: {\n        fontSize: 13,\n        fontWeight: 500,\n        cursor: "pointer",\n        flex: "1 1 140px"\n      }\n    }, s.name), /*#__PURE__*/React.createElement("button", {\n      onClick: () => onSetAbsen(s.id, dateKey, "Hadir", ""),\n      style: {\n        fontSize: 12,\n        border: "none",\n        borderRadius: 6,\n        padding: "5px 10px",\n        cursor: "pointer",\n        background: status === "Hadir" ? GREEN : GREEN_BG,\n        color: status === "Hadir" ? "#fff" : GREEN\n      }\n    }, "Hadir"), /*#__PURE__*/React.createElement("button", {\n      onClick: () => onSetAbsen(s.id, dateKey, "Tidak Hadir", notes[s.id] || ""),\n      style: {\n        fontSize: 12,\n        border: "none",\n        borderRadius: 6,\n        padding: "5px 10px",\n        cursor: "pointer",\n        background: status === "Tidak Hadir" ? RED : RED_BG,\n        color: status === "Tidak Hadir" ? "#fff" : RED\n      }\n    }, "Tidak Hadir"), /*#__PURE__*/React.createElement("input", {\n      value: notes[s.id] !== undefined ? notes[s.id] : e && e.status === "Tidak Hadir" ? e.keterangan : "",\n      onChange: ev => setNotes(v => ({\n        ...v,\n        [s.id]: ev.target.value\n      })),\n      placeholder: "keterangan (sakit/izin)",\n      style: {\n        ...inputStyle,\n        fontSize: 12,\n        padding: "5px 8px",\n        width: 140\n      }\n    }));\n  }), !filtered.length && /*#__PURE__*/React.createElement("div", {\n    style: {\n      color: TEXT_MUTED,\n      fontSize: 13\n    }\n  }, students.length ? "Tidak ada nama yang cocok." : "Belum ada santri.")));\n}\nfunction SetoranPage({\n  students,\n  onAddEntry,\n  onDeleteEntry,\n  onSelect,\n  pendingOf\n}) {\n  const [dateKey, setDateKey] = useState(() => new Date().toISOString().slice(0, 10));\n  const [inputs, setInputs] = useState({});\n  const [query, setQuery] = useState("");\n  function entriesFor(student) {\n    return student.setoran.filter(e => e.dateKey === dateKey);\n  }\n  function totalFor(student) {\n    return entriesFor(student).reduce((a, e) => a + e.poin, 0);\n  }\n  function addSetoran(student) {\n    const ket = (inputs[student.id] || "").trim() || "Setoran";\n    onAddEntry(student.id, "setoran", {\n      dateKey,\n      poin: 1,\n      keterangan: ket\n    });\n    setInputs(v => ({\n      ...v,\n      [student.id]: ""\n    }));\n  }\n  const pend = s => pendingOf ? pendingOf(s, dateKey) : [];\n  const okPulang = s => totalFor(s) >= MIN_SETORAN_POIN && pend(s).length === 0;\n  const bolehPulang = students.filter(okPulang);\n  const belumBolehPulang = students.filter(s => !okPulang(s));\n  const doneCount = bolehPulang.length;\n  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 6\n    }\n  }, "Setoran harian \\xB7 belajar malam"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 16\n    }\n  }, "Minimal ", MIN_SETORAN_POIN, " poin setoran (bebas jenisnya) sebelum boleh pulang. Santri yang kena kelas malam juga harus menyelesaikan tugasnya."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 14,\n      marginBottom: 14,\n      flexWrap: "wrap"\n    }\n  }, /*#__PURE__*/React.createElement("input", {\n    type: "date",\n    value: dateKey,\n    onChange: e => setDateKey(e.target.value),\n    style: inputStyle\n  }), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      color: TEXT_MUTED\n    }\n  }, /*#__PURE__*/React.createElement("strong", {\n    style: {\n      color: GREEN\n    }\n  }, doneCount), " / ", students.length, " sudah memenuhi syarat pulang")), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 14,\n      marginBottom: 20,\n      flexWrap: "wrap"\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: GREEN_BG,\n      borderRadius: 10,\n      padding: 14,\n      flex: "1 1 260px",\n      minWidth: 220\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: GREEN,\n      fontWeight: 600,\n      marginBottom: 8\n    }\n  }, "Sudah boleh pulang (", bolehPulang.length, ")"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexWrap: "wrap",\n      gap: 6\n    }\n  }, bolehPulang.map(s => /*#__PURE__*/React.createElement("span", {\n    key: s.id,\n    onClick: () => onSelect(s.id),\n    style: {\n      fontSize: 12,\n      background: "#fff",\n      color: GREEN,\n      borderRadius: 6,\n      padding: "4px 9px",\n      cursor: "pointer"\n    }\n  }, s.name)), !bolehPulang.length && /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED\n    }\n  }, "Belum ada."))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: RED_BG,\n      borderRadius: 10,\n      padding: 14,\n      flex: "1 1 260px",\n      minWidth: 220\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: RED,\n      fontWeight: 600,\n      marginBottom: 8\n    }\n  }, "Belum boleh pulang (", belumBolehPulang.length, ")"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexWrap: "wrap",\n      gap: 6\n    }\n  }, belumBolehPulang.map(s => /*#__PURE__*/React.createElement("span", {\n    key: s.id,\n    onClick: () => onSelect(s.id),\n    style: {\n      fontSize: 12,\n      background: "#fff",\n      color: RED,\n      borderRadius: 6,\n      padding: "4px 9px",\n      cursor: "pointer"\n    }\n  }, s.name, " \\xB7 ", totalFor(s), "/", MIN_SETORAN_POIN, pend(s).length ? ` \\u00b7 tugas: ${pend(s).join(", ")}` : "")), !belumBolehPulang.length && /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED\n    }\n  }, "Semua sudah selesai.")))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 8,\n      marginBottom: 16,\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 8,\n      padding: "8px 12px",\n      maxWidth: 300\n    }\n  }, /*#__PURE__*/React.createElement(Search, {\n    size: 15,\n    color: TEXT_MUTED\n  }), /*#__PURE__*/React.createElement("input", {\n    value: query,\n    onChange: e => setQuery(e.target.value),\n    placeholder: "Cari nama santri",\n    style: {\n      border: "none",\n      outline: "none",\n      fontSize: 13,\n      flex: 1,\n      background: "transparent"\n    }\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexDirection: "column",\n      gap: 10,\n      maxWidth: 560\n    }\n  }, students.filter(s => s.name.toLowerCase().includes(query.toLowerCase())).map(s => {\n    const entries = entriesFor(s);\n    const total = entries.reduce((a, e) => a + e.poin, 0);\n    const p = pend(s);\n    const done = total >= MIN_SETORAN_POIN && p.length === 0;\n    return /*#__PURE__*/React.createElement("div", {\n      key: s.id,\n      style: {\n        background: CARD,\n        border: `1px solid ${BORDER}`,\n        borderRadius: 10,\n        padding: 14\n      }\n    }, /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        alignItems: "center",\n        justifyContent: "space-between",\n        marginBottom: entries.length ? 8 : 0\n      }\n    }, /*#__PURE__*/React.createElement("span", {\n      onClick: () => onSelect(s.id),\n      style: {\n        fontSize: 13,\n        fontWeight: 500,\n        cursor: "pointer"\n      }\n    }, s.name), /*#__PURE__*/React.createElement("span", {\n      style: {\n        fontSize: 11.5,\n        fontWeight: 600,\n        padding: "3px 9px",\n        borderRadius: 6,\n        background: done ? GREEN_BG : RED_BG,\n        color: done ? GREEN : RED\n      }\n    }, done ? `Boleh pulang \\u00b7 ${total}/${MIN_SETORAN_POIN}` : `Belum \\u00b7 ${total}/${MIN_SETORAN_POIN}${p.length ? ` \\u00b7 tugas ${p.join(", ")}` : ""}`)), entries.length > 0 && /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        flexWrap: "wrap",\n        gap: 6,\n        marginBottom: 8\n      }\n    }, entries.map(e => /*#__PURE__*/React.createElement("span", {\n      key: e.id,\n      style: {\n        display: "inline-flex",\n        alignItems: "center",\n        gap: 5,\n        fontSize: 11.5,\n        background: PAPER,\n        borderRadius: 6,\n        padding: "3px 8px",\n        color: TEXT_MUTED\n      }\n    }, e.keterangan, /*#__PURE__*/React.createElement(Trash2, {\n      size: 11,\n      style: {\n        cursor: "pointer"\n      },\n      onClick: () => onDeleteEntry(s.id, "setoran", e.id)\n    })))), /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        gap: 6\n      }\n    }, /*#__PURE__*/React.createElement("input", {\n      value: inputs[s.id] || "",\n      onChange: e => setInputs(v => ({\n        ...v,\n        [s.id]: e.target.value\n      })),\n      onKeyDown: e => e.key === "Enter" && addSetoran(s),\n      placeholder: "mis. hafalan Imla 5 baris",\n      style: {\n        ...inputStyle,\n        flex: 1,\n        fontSize: 12.5,\n        padding: "6px 9px"\n      }\n    }), /*#__PURE__*/React.createElement("button", {\n      onClick: () => addSetoran(s),\n      style: {\n        display: "flex",\n        alignItems: "center",\n        gap: 4,\n        background: INK,\n        color: "#fff",\n        border: "none",\n        borderRadius: 6,\n        padding: "0 12px",\n        cursor: "pointer",\n        fontSize: 12\n      }\n    }, /*#__PURE__*/React.createElement(Plus, {\n      size: 12\n    }), " 1 poin")));\n  }), !students.filter(s => s.name.toLowerCase().includes(query.toLowerCase())).length && /*#__PURE__*/React.createElement("div", {\n    style: {\n      color: TEXT_MUTED,\n      fontSize: 13\n    }\n  }, students.length ? "Tidak ada nama yang cocok." : "Belum ada santri.")));\n}\nfunction BulkRegularInput({\n  subjects,\n  students,\n  onSave,\n  showToast\n}) {\n  const firstNonCore = subjects.find(s => !CORE_SUBJECTS.includes(s)) || subjects[0];\n  const [subject, setSubject] = useState(firstNonCore);\n  const [values, setValues] = useState({});\n  const [query, setQuery] = useState("");\n  function save() {\n    let count = 0;\n    students.forEach(s => {\n      const v = values[s.id];\n      if (v !== undefined && v !== "") {\n        onSave(s.id, "regularScores", {\n          subject,\n          value: Number(v),\n          date: today()\n        });\n        count++;\n      }\n    });\n    setValues({});\n    showToast(count ? `Nilai ${subject} tersimpan untuk ${count} santri.` : "Belum ada nilai yang diisi.");\n  }\n  const filtered = students.filter(s => s.name.toLowerCase().includes(query.toLowerCase()));\n  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 16\n    }\n  }, "Input nilai massal"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 10,\n      marginBottom: 12,\n      flexWrap: "wrap"\n    }\n  }, /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 13,\n      color: TEXT_MUTED\n    }\n  }, "Mata pelajaran"), /*#__PURE__*/React.createElement("select", {\n    value: subject,\n    onChange: e => setSubject(e.target.value),\n    style: inputStyle\n  }, subjects.map(s => /*#__PURE__*/React.createElement("option", {\n    key: s,\n    value: s\n  }, s))), /*#__PURE__*/React.createElement("button", {\n    onClick: save,\n    style: {\n      background: INK,\n      color: "#fff",\n      border: "none",\n      borderRadius: 6,\n      padding: "8px 16px",\n      cursor: "pointer",\n      fontSize: 13\n    }\n  }, "Simpan semua")), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 8,\n      marginBottom: 16,\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 8,\n      padding: "8px 12px",\n      maxWidth: 300\n    }\n  }, /*#__PURE__*/React.createElement(Search, {\n    size: 15,\n    color: TEXT_MUTED\n  }), /*#__PURE__*/React.createElement("input", {\n    value: query,\n    onChange: e => setQuery(e.target.value),\n    placeholder: "Cari nama santri",\n    style: {\n      border: "none",\n      outline: "none",\n      fontSize: 13,\n      flex: 1,\n      background: "transparent"\n    }\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      overflow: "hidden",\n      maxWidth: 460\n    }\n  }, filtered.map((s, i) => /*#__PURE__*/React.createElement("div", {\n    key: s.id,\n    style: {\n      display: "flex",\n      alignItems: "center",\n      justifyContent: "space-between",\n      padding: "8px 14px",\n      borderTop: i ? `1px solid ${BORDER}` : "none"\n    }\n  }, /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 13\n    }\n  }, s.name), /*#__PURE__*/React.createElement("input", {\n    type: "number",\n    min: "0",\n    max: "100",\n    placeholder: "-",\n    value: values[s.id] || "",\n    onChange: e => setValues(v => ({\n      ...v,\n      [s.id]: e.target.value\n    })),\n    style: {\n      ...inputStyle,\n      width: 64,\n      textAlign: "center"\n    }\n  }))), !filtered.length && /*#__PURE__*/React.createElement("div", {\n    style: {\n      padding: 20,\n      color: TEXT_MUTED,\n      textAlign: "center"\n    }\n  }, students.length ? "Tidak ada nama yang cocok." : "Belum ada santri.")));\n}\nfunction BulkExamInput({\n  students,\n  onSaveExam,\n  showToast,\n  quickImports\n}) {\n  const [subject, setSubject] = useState(CORE_SUBJECTS[0]);\n  const [month, setMonth] = useState("Bulan 1");\n  const [values, setValues] = useState({});\n  const [query, setQuery] = useState("");\n  function save() {\n    let count = 0;\n    students.forEach(s => {\n      const v = values[s.id];\n      if (v !== undefined && v !== "") {\n        onSaveExam(s.id, subject, month, Number(v));\n        count++;\n      }\n    });\n    setValues({});\n    showToast(count ? `Ujian ${subject} (${month}) tersimpan untuk ${count} santri (menimpa nilai lama jika ada).` : "Belum ada nilai yang diisi.");\n  }\n  const filtered = students.filter(s => s.name.toLowerCase().includes(query.toLowerCase()));\n  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 16\n    }\n  }, "Ujian bulanan massal"), quickImports && quickImports.length > 0 && /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: GOLD_BG,\n      borderRadius: 10,\n      padding: 14,\n      marginBottom: 16,\n      maxWidth: 460\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 11,\n      color: GOLD,\n      fontWeight: 600,\n      textTransform: "uppercase",\n      letterSpacing: 0.3,\n      marginBottom: 8\n    }\n  }, "Impor cepat dari tabel"), quickImports.map((q, i) => /*#__PURE__*/React.createElement("div", {\n    key: i,\n    style: {\n      display: "flex",\n      alignItems: "center",\n      justifyContent: "space-between",\n      gap: 10,\n      padding: "8px 0",\n      borderTop: i ? "1px solid rgba(184,134,46,0.25)" : "none"\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12.5,\n      color: "#5A4415",\n      flex: 1\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontWeight: 600\n    }\n  }, q.title), /*#__PURE__*/React.createElement("div", {\n    style: {\n      opacity: 0.85\n    }\n  }, q.desc), q.audit && /*#__PURE__*/React.createElement("div", {\n    style: {\n      marginTop: 6,\n      fontWeight: 600,\n      color: q.audit.bad === 0 && q.audit.stacked === 0 ? GREEN : RED\n    }\n  }, q.audit.bad === 0 && q.audit.stacked === 0 ? `\\u2713 Semua ${q.audit.total} nilai sudah sesuai file fiks` : `${q.audit.ok}/${q.audit.total} sesuai \\u00b7 ${q.audit.bad} beda atau kosong${q.audit.stacked ? ` \\u00b7 ${q.audit.stacked} mapel nilainya dobel` : ""} \\u2192 klik Impor untuk merapikan`)), /*#__PURE__*/React.createElement("button", {\n    onClick: q.onClick,\n    style: {\n      background: GOLD,\n      color: "#fff",\n      border: "none",\n      borderRadius: 6,\n      padding: "7px 14px",\n      cursor: "pointer",\n      fontSize: 12.5,\n      whiteSpace: "nowrap"\n    }\n  }, "Impor")))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 10,\n      marginBottom: 12,\n      flexWrap: "wrap"\n    }\n  }, /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 13,\n      color: TEXT_MUTED\n    }\n  }, "Mapel"), /*#__PURE__*/React.createElement("select", {\n    value: subject,\n    onChange: e => setSubject(e.target.value),\n    style: inputStyle\n  }, CORE_SUBJECTS.map(s => /*#__PURE__*/React.createElement("option", {\n    key: s,\n    value: s\n  }, s))), /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 13,\n      color: TEXT_MUTED\n    }\n  }, "Periode"), /*#__PURE__*/React.createElement("input", {\n    value: month,\n    onChange: e => setMonth(e.target.value),\n    style: {\n      ...inputStyle,\n      width: 110\n    }\n  }), /*#__PURE__*/React.createElement("button", {\n    onClick: save,\n    style: {\n      background: INK,\n      color: "#fff",\n      border: "none",\n      borderRadius: 6,\n      padding: "8px 16px",\n      cursor: "pointer",\n      fontSize: 13\n    }\n  }, "Simpan semua")), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 8,\n      marginBottom: 16,\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 8,\n      padding: "8px 12px",\n      maxWidth: 300\n    }\n  }, /*#__PURE__*/React.createElement(Search, {\n    size: 15,\n    color: TEXT_MUTED\n  }), /*#__PURE__*/React.createElement("input", {\n    value: query,\n    onChange: e => setQuery(e.target.value),\n    placeholder: "Cari nama santri",\n    style: {\n      border: "none",\n      outline: "none",\n      fontSize: 13,\n      flex: 1,\n      background: "transparent"\n    }\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      overflow: "hidden",\n      maxWidth: 460\n    }\n  }, filtered.map((s, i) => /*#__PURE__*/React.createElement("div", {\n    key: s.id,\n    style: {\n      display: "flex",\n      alignItems: "center",\n      justifyContent: "space-between",\n      padding: "8px 14px",\n      borderTop: i ? `1px solid ${BORDER}` : "none"\n    }\n  }, /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 13\n    }\n  }, s.name), /*#__PURE__*/React.createElement("select", {\n    value: values[s.id] || "",\n    onChange: e => setValues(v => ({\n      ...v,\n      [s.id]: e.target.value\n    })),\n    style: {\n      ...inputStyle,\n      width: 84\n    }\n  }, /*#__PURE__*/React.createElement("option", {\n    value: ""\n  }, "-"), EXAM_VALUES.map(v => /*#__PURE__*/React.createElement("option", {\n    key: v,\n    value: v\n  }, v))))), !filtered.length && /*#__PURE__*/React.createElement("div", {\n    style: {\n      padding: 20,\n      color: TEXT_MUTED,\n      textAlign: "center"\n    }\n  }, students.length ? "Tidak ada nama yang cocok." : "Belum ada santri.")));\n}\nfunction MapelPage({\n  subjects,\n  students,\n  renameSubject\n}) {\n  const [openSubject, setOpenSubject] = useState(null);\n  const [mapelQuery, setMapelQuery] = useState("");\n  function progressFor(subject) {\n    const core = CORE_SUBJECTS.includes(subject);\n    return students.map(s => {\n      let value = null;\n      if (core) {\n        value = latestExam(s, subject);\n      } else {\n        const entries = s.regularScores.filter(e => e.subject === subject);\n        value = entries.length ? entries[entries.length - 1].value : null;\n      }\n      return {\n        name: s.name,\n        value\n      };\n    }).sort((a, b) => (b.value ?? -1) - (a.value ?? -1));\n  }\n  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 6\n    }\n  }, "Mata pelajaran"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 16\n    }\n  }, "Klik nama mapel untuk lihat progres nilai tiap santri."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 20,\n      flexWrap: "wrap",\n      alignItems: "flex-start"\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      padding: 4,\n      width: 400\n    }\n  }, subjects.map((subj, i) => {\n    const core = CORE_SUBJECTS.includes(subj);\n    const active = openSubject === subj;\n    return /*#__PURE__*/React.createElement("div", {\n      key: i,\n      style: {\n        display: "flex",\n        alignItems: "center",\n        gap: 10,\n        padding: "8px 12px",\n        borderBottom: i < subjects.length - 1 ? `1px solid ${BORDER}` : "none",\n        background: active ? PAPER : "transparent",\n        borderRadius: 6,\n        cursor: "pointer"\n      },\n      onClick: () => setOpenSubject(active ? null : subj)\n    }, /*#__PURE__*/React.createElement("span", {\n      style: {\n        fontSize: 12,\n        color: TEXT_MUTED,\n        width: 20\n      }\n    }, i + 1, "."), core ? /*#__PURE__*/React.createElement("span", {\n      style: {\n        flex: 1,\n        fontSize: 13\n      }\n    }, subj) : /*#__PURE__*/React.createElement("input", {\n      value: subj,\n      onClick: e => e.stopPropagation(),\n      onChange: e => renameSubject(i, e.target.value),\n      style: {\n        ...inputStyle,\n        flex: 1,\n        border: "none",\n        padding: "4px 0",\n        background: "transparent",\n        color: TEXT\n      }\n    }), core && /*#__PURE__*/React.createElement("span", {\n      style: {\n        fontSize: 11,\n        background: GOLD_BG,\n        color: GOLD,\n        borderRadius: 5,\n        padding: "2px 7px"\n      }\n    }, "Kelulusan"), /*#__PURE__*/React.createElement(ChevronRight, {\n      size: 14,\n      color: TEXT_MUTED,\n      style: {\n        transform: active ? "rotate(90deg)" : "none"\n      }\n    }));\n  })), openSubject && /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      padding: 16,\n      flex: "1 1 280px",\n      minWidth: 260\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 14,\n      fontWeight: 500,\n      marginBottom: 4\n    }\n  }, openSubject), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 10\n    }\n  }, CORE_SUBJECTS.includes(openSubject) ? "Progres berdasarkan nilai ujian bulanan terakhir." : "Progres berdasarkan nilai akademik terakhir."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 6,\n      marginBottom: 12,\n      background: PAPER,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 6,\n      padding: "6px 10px"\n    }\n  }, /*#__PURE__*/React.createElement(Search, {\n    size: 13,\n    color: TEXT_MUTED\n  }), /*#__PURE__*/React.createElement("input", {\n    value: mapelQuery,\n    onChange: e => setMapelQuery(e.target.value),\n    placeholder: "Cari nama santri",\n    style: {\n      border: "none",\n      outline: "none",\n      fontSize: 12.5,\n      flex: 1,\n      background: "transparent"\n    }\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexDirection: "column",\n      gap: 8\n    }\n  }, progressFor(openSubject).filter(row => row.name.toLowerCase().includes(mapelQuery.toLowerCase())).map((row, i) => /*#__PURE__*/React.createElement("div", {\n    key: i\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      justifyContent: "space-between",\n      fontSize: 12.5,\n      marginBottom: 3\n    }\n  }, /*#__PURE__*/React.createElement("span", null, row.name), /*#__PURE__*/React.createElement("span", {\n    style: {\n      color: statusColors(statusOf(row.value)).fg\n    }\n  }, row.value !== null ? row.value : "belum ada")), /*#__PURE__*/React.createElement(ProgressBar, {\n    pct: row.value || 0,\n    color: statusColors(statusOf(row.value)).fg,\n    height: 5\n  }))), !students.length && /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED\n    }\n  }, "Belum ada santri.")))));\n}\nfunction RoadmapPage({\n  students,\n  currentWeek,\n  setCurrentWeek,\n  onSelect\n}) {\n  const phase = currentPhase(currentWeek);\n  const phaseIndex = PHASES.indexOf(phase);\n  const [query, setQuery] = useState("");\n  const matches = name => name.toLowerCase().includes(query.toLowerCase());\n  const laggingByCore = CORE_SUBJECTS.map(subj => {\n    if (phase.milestone === null) return {\n      subject: subj,\n      rows: []\n    };\n    const rows = students.map(s => ({\n      id: s.id,\n      name: s.name,\n      value: latestExam(s, subj)\n    })).filter(r => (r.value === null || r.value < phase.milestone) && matches(r.name)).sort((a, b) => (a.value ?? -1) - (b.value ?? -1));\n    return {\n      subject: subj,\n      rows\n    };\n  });\n  const weakList = students.map(s => ({\n    id: s.id,\n    name: s.name,\n    weak: weakRegularSubjects(s)\n  })).filter(s => s.weak.length > 0 && matches(s.name));\n  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 6\n    }\n  }, "Roadmap 16 minggu"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 14\n    }\n  }, "Target bertahap untuk 5 mapel kelulusan, dan titik lemah otomatis untuk mapel biasa."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 8,\n      marginBottom: 18,\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 8,\n      padding: "8px 12px",\n      maxWidth: 300\n    }\n  }, /*#__PURE__*/React.createElement(Search, {\n    size: 15,\n    color: TEXT_MUTED\n  }), /*#__PURE__*/React.createElement("input", {\n    value: query,\n    onChange: e => setQuery(e.target.value),\n    placeholder: "Cari nama santri",\n    style: {\n      border: "none",\n      outline: "none",\n      fontSize: 13,\n      flex: 1,\n      background: "transparent"\n    }\n  })), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 10,\n      marginBottom: 18\n    }\n  }, /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 13,\n      color: TEXT_MUTED\n    }\n  }, "Minggu ke"), /*#__PURE__*/React.createElement("button", {\n    onClick: () => setCurrentWeek(currentWeek - 1),\n    style: {\n      border: `1px solid ${BORDER}`,\n      background: "#fff",\n      borderRadius: 6,\n      width: 28,\n      height: 28,\n      cursor: "pointer",\n      display: "flex",\n      alignItems: "center",\n      justifyContent: "center"\n    }\n  }, /*#__PURE__*/React.createElement(ChevronLeft, {\n    size: 14\n  })), /*#__PURE__*/React.createElement("input", {\n    type: "number",\n    min: 1,\n    max: 16,\n    value: currentWeek,\n    onChange: e => setCurrentWeek(Number(e.target.value) || 1),\n    style: {\n      ...inputStyle,\n      width: 56,\n      textAlign: "center"\n    }\n  }), /*#__PURE__*/React.createElement("button", {\n    onClick: () => setCurrentWeek(currentWeek + 1),\n    style: {\n      border: `1px solid ${BORDER}`,\n      background: "#fff",\n      borderRadius: 6,\n      width: 28,\n      height: 28,\n      cursor: "pointer",\n      display: "flex",\n      alignItems: "center",\n      justifyContent: "center"\n    }\n  }, /*#__PURE__*/React.createElement(ChevronRight, {\n    size: 14\n  })), /*#__PURE__*/React.createElement("span", {\n    style: {\n      fontSize: 13,\n      color: TEXT_MUTED\n    }\n  }, "dari 16")), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      gap: 4,\n      marginBottom: 14\n    }\n  }, PHASES.map((p, i) => /*#__PURE__*/React.createElement("div", {\n    key: p.name,\n    style: {\n      flex: 1,\n      height: 6,\n      borderRadius: 4,\n      background: i === phaseIndex ? GOLD : i < phaseIndex ? GREEN : "#EDEAE0"\n    },\n    title: p.name\n  }))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      padding: 18,\n      marginBottom: 22,\n      maxWidth: 520\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 11,\n      color: GOLD,\n      textTransform: "uppercase",\n      letterSpacing: 0.4,\n      marginBottom: 4\n    }\n  }, "Fase ", phaseIndex + 1, " \\xB7 Minggu ", phase.range[0], "\\u2013", phase.range[1]), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 16,\n      fontFamily: "Georgia, serif",\n      marginBottom: 6\n    }\n  }, phase.name), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      color: TEXT_MUTED\n    }\n  }, phase.desc), phase.milestone !== null && /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      marginTop: 8\n    }\n  }, "Target mapel kelulusan fase ini: ", /*#__PURE__*/React.createElement("strong", null, phase.milestone), " / 100")), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      fontWeight: 500,\n      marginBottom: 10\n    }\n  }, "Kelulusan \\xB7 santri yang tertinggal dari target fase ini"), phase.milestone === null ? /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 22\n    }\n  }, "Masih fase pemetaan, belum ada target angka untuk dibandingkan.") : /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexDirection: "column",\n      gap: 14,\n      marginBottom: 22\n    }\n  }, laggingByCore.map(({\n    subject,\n    rows\n  }) => /*#__PURE__*/React.createElement("div", {\n    key: subject,\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      padding: 16,\n      maxWidth: 520\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      fontWeight: 500,\n      marginBottom: rows.length ? 10 : 0\n    }\n  }, subject), rows.length ? rows.map(r => /*#__PURE__*/React.createElement("div", {\n    key: r.id,\n    onClick: () => onSelect(r.id),\n    style: {\n      display: "flex",\n      justifyContent: "space-between",\n      fontSize: 12.5,\n      padding: "5px 0",\n      borderTop: `1px solid ${BORDER}`,\n      cursor: "pointer"\n    }\n  }, /*#__PURE__*/React.createElement("span", null, r.name), /*#__PURE__*/React.createElement("span", {\n    style: {\n      color: RED\n    }\n  }, r.value !== null ? `${r.value} / ${phase.milestone}` : "belum dinilai"))) : /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: GREEN\n    }\n  }, "Semua santri sudah mencapai target fase ini.")))), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      fontWeight: 500,\n      marginBottom: 10\n    }\n  }, "Mapel biasa \\xB7 titik lemah per santri (nilai ", PERHATIAN_MAX, " ke bawah)"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      overflow: "hidden",\n      maxWidth: 520\n    }\n  }, weakList.map((s, i) => /*#__PURE__*/React.createElement("div", {\n    key: s.id,\n    onClick: () => onSelect(s.id),\n    style: {\n      padding: "10px 14px",\n      borderTop: i ? `1px solid ${BORDER}` : "none",\n      cursor: "pointer"\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      fontWeight: 500,\n      marginBottom: 3\n    }\n  }, s.name), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED\n    }\n  }, "Fokus: ", s.weak.map(w => `${w.subject} (${w.value})`).join(", ")))), !weakList.length && /*#__PURE__*/React.createElement("div", {\n    style: {\n      padding: 16,\n      color: TEXT_MUTED,\n      fontSize: 12\n    }\n  }, "Belum ada data nilai mapel biasa, atau tidak ada yang bernilai ", PERHATIAN_MAX, " ke bawah.")));\n}\nfunction BackupPage({\n  students,\n  subjects,\n  currentWeek,\n  showToast,\n  onImportBaseline,\n  onRestoreBackup\n}) {\n  const fileRef = useRef(null);\n  const [downloadsCap, setDownloadsCap] = useState(null);\n  useEffect(() => {\n    let mounted = true;\n    (async () => {\n      try {\n        const cap = await claude.use("downloads");\n        if (mounted) setDownloadsCap(cap);\n      } catch (e) {}\n    })();\n    return () => {\n      mounted = false;\n    };\n  }, []);\n  async function handleExport() {\n    if (!downloadsCap) {\n      showToast("Fitur unduh belum siap, coba lagi sebentar.");\n      return;\n    }\n    const payload = JSON.stringify({\n      students,\n      subjects,\n      currentWeek\n    }, null, 2);\n    try {\n      await downloadsCap.save({\n        filename: `b15-backup-${new Date().toISOString().slice(0, 10)}.json`,\n        data: payload\n      });\n      showToast("Cadangan data berhasil diunduh.");\n    } catch (err) {\n      if (err && err.code === "declined") return;\n      showToast("Gagal mengunduh cadangan.");\n    }\n  }\n  function handleImportFile(e) {\n    const file = e.target.files[0];\n    if (!file) return;\n    const reader = new FileReader();\n    reader.onload = ev => {\n      try {\n        const parsed = JSON.parse(ev.target.result);\n        if (!Array.isArray(parsed.students) || !Array.isArray(parsed.subjects)) {\n          throw new Error("format tidak dikenali");\n        }\n        onRestoreBackup(parsed);\n      } catch (err) {\n        showToast("Gagal membaca file cadangan. Pastikan file JSON yang benar.");\n      }\n    };\n    reader.readAsText(file);\n    e.target.value = "";\n  }\n  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 24,\n      fontWeight: 400,\n      marginBottom: 6\n    }\n  }, "Cadangan data"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 20,\n      maxWidth: 460\n    }\n  }, "Data dashboard ini tersimpan di database bersama, terus update tiap ada perubahan. Tetap ada baiknya sesekali unduh cadangan manual biar tetap aman."), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      padding: 20,\n      maxWidth: 420,\n      marginBottom: 16\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      fontWeight: 500,\n      marginBottom: 6\n    }\n  }, "Impor nilai awal tahun"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 12\n    }\n  }, "Masukkan nilai Ibadah, Berhitung, dan Imla\' dari rapor penempatan awal tahun (kelas asal sebelum B15) untuk santri yang cocok namanya. Aman dijalankan berkali-kali, santri yang sudah diimpor akan dilewati."), /*#__PURE__*/React.createElement("button", {\n    onClick: onImportBaseline,\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 6,\n      background: GOLD,\n      color: "#fff",\n      border: "none",\n      borderRadius: 6,\n      padding: "9px 16px",\n      cursor: "pointer",\n      fontSize: 13\n    }\n  }, /*#__PURE__*/React.createElement(Upload, {\n    size: 14\n  }), " Impor nilai awal tahun")), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      padding: 20,\n      maxWidth: 420,\n      marginBottom: 16\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      fontWeight: 500,\n      marginBottom: 6\n    }\n  }, "Unduh cadangan"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 12\n    }\n  }, "Simpan seluruh data (", students.length, " santri) sebagai file .json ke perangkat lu."), /*#__PURE__*/React.createElement("button", {\n    onClick: handleExport,\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 6,\n      background: INK,\n      color: "#fff",\n      border: "none",\n      borderRadius: 6,\n      padding: "9px 16px",\n      cursor: "pointer",\n      fontSize: 13\n    }\n  }, /*#__PURE__*/React.createElement(Download, {\n    size: 14\n  }), " Unduh backup (.json)")), /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: CARD,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 10,\n      padding: 20,\n      maxWidth: 420\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      fontWeight: 500,\n      marginBottom: 6\n    }\n  }, "Pulihkan dari cadangan"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginBottom: 12\n    }\n  }, "Menimpa data santri yang cocok id/no. daftarnya dengan isi file cadangan yang dipilih."), /*#__PURE__*/React.createElement("input", {\n    ref: fileRef,\n    type: "file",\n    accept: "application/json",\n    onChange: handleImportFile,\n    style: {\n      display: "none"\n    }\n  }), /*#__PURE__*/React.createElement("button", {\n    onClick: () => fileRef.current.click(),\n    style: {\n      display: "flex",\n      alignItems: "center",\n      gap: 6,\n      background: "#fff",\n      color: TEXT,\n      border: `1px solid ${BORDER}`,\n      borderRadius: 6,\n      padding: "9px 16px",\n      cursor: "pointer",\n      fontSize: 13\n    }\n  }, /*#__PURE__*/React.createElement(Upload, {\n    size: 14\n  }), " Pilih file cadangan")));\n}\nfunction LogRow({\n  children,\n  onDelete\n}) {\n  return /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      alignItems: "center",\n      justifyContent: "space-between",\n      gap: 8,\n      padding: "7px 0",\n      borderTop: `1px solid ${BORDER}`,\n      fontSize: 12.5\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      flex: 1,\n      color: TEXT_MUTED\n    }\n  }, children), /*#__PURE__*/React.createElement(IconBtn, {\n    onClick: onDelete\n  }));\n}\nfunction StudentProfile({\n  student,\n  subjects,\n  onClose,\n  onAddEntry,\n  onDeleteEntry\n}) {\n  const [nsNote, setNsNote] = useState("");\n  const [nsStatus, setNsStatus] = useState("Sedang");\n  const [ibValue, setIbValue] = useState("");\n  const [ipDate, setIpDate] = useState("");\n  const [ipKeterangan, setIpKeterangan] = useState("");\n  const [akNote, setAkNote] = useState("");\n  const [akStatus, setAkStatus] = useState("Baik");\n  const [tlNote, setTlNote] = useState("");\n  const [tlStatus, setTlStatus] = useState("Baik");\n  const [kbWeek, setKbWeek] = useState("");\n  const [kbPersonal, setKbPersonal] = useState("");\n  const [kbKamar, setKbKamar] = useState("");\n  const [kbKelas, setKbKelas] = useState("");\n  const [kbBarang, setKbBarang] = useState("");\n  const [tgArea, setTgArea] = useState("");\n  const [tgTarget, setTgTarget] = useState("");\n  const [tgDeadline, setTgDeadline] = useState("");\n  const [tgStatus, setTgStatus] = useState("Belum");\n  const id = student.id;\n  return /*#__PURE__*/React.createElement("div", {\n    onClick: onClose,\n    style: {\n      position: "fixed",\n      inset: 0,\n      background: "rgba(30,61,54,0.35)",\n      display: "flex",\n      justifyContent: "flex-end",\n      zIndex: 10\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    onClick: e => e.stopPropagation(),\n    style: {\n      width: 420,\n      background: CARD,\n      height: "100%",\n      padding: 24,\n      overflowY: "auto"\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      justifyContent: "space-between",\n      alignItems: "flex-start",\n      marginBottom: 18\n    }\n  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {\n    style: {\n      fontFamily: "Georgia, serif",\n      fontSize: 20,\n      fontWeight: 400,\n      margin: 0\n    }\n  }, student.name), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      marginTop: 4\n    }\n  }, "Kelas B15", student.noDaftar ? ` \\u00b7 No. ${student.noDaftar}` : "")), /*#__PURE__*/React.createElement("button", {\n    onClick: onClose,\n    style: {\n      border: "none",\n      background: "transparent",\n      cursor: "pointer",\n      color: TEXT_MUTED\n    }\n  }, /*#__PURE__*/React.createElement(X, {\n    size: 18\n  }))), student.baseline && /*#__PURE__*/React.createElement("div", {\n    style: {\n      background: GOLD_BG,\n      borderRadius: 8,\n      padding: 14,\n      marginBottom: 18\n    }\n  }, /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 11,\n      color: GOLD,\n      fontWeight: 600,\n      textTransform: "uppercase",\n      letterSpacing: 0.3,\n      marginBottom: 8\n    }\n  }, "Penempatan awal tahun"), /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "grid",\n      gridTemplateColumns: "1fr 1fr",\n      gap: 6,\n      fontSize: 12.5,\n      color: "#5A4415"\n    }\n  }, /*#__PURE__*/React.createElement("span", null, "Kelas awal: ", student.baseline.kelasAwal), /*#__PURE__*/React.createElement("span", null, "Rata-rata: ", student.baseline.rataRata), /*#__PURE__*/React.createElement("span", null, "Kelulusan: ", student.baseline.kelulusan, " (", student.baseline.ketKelulusan, ")"), /*#__PURE__*/React.createElement("span", null, "Akselerasi: ", student.baseline.akselerasi, " (", student.baseline.ketAkselerasi, ")"), /*#__PURE__*/React.createElement("span", null, "No. absen akhir tahun: ", student.baseline.noAbsen), /*#__PURE__*/React.createElement("span", null, "Kelas akhir: ", student.baseline.kelasAkhir))), (() => {\n    const list = scoreList(student, false);\n    if (!list.length) return null;\n    const tot = list.reduce((a, r) => a + r.value, 0);\n    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(SectionLabel, {\n      text: "Nilai terakhir tiap mapel"\n    }), /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        flexWrap: "wrap",\n        gap: 6,\n        marginBottom: 8\n      }\n    }, list.map(r => /*#__PURE__*/React.createElement("span", {\n      key: r.subject,\n      style: {\n        fontSize: 12,\n        borderRadius: 6,\n        padding: "4px 9px",\n        background: r.value <= PERHATIAN_MAX ? RED_BG : GREEN_BG,\n        color: r.value <= PERHATIAN_MAX ? RED : GREEN\n      }\n    }, r.subject, " \\xB7 ", r.value))), /*#__PURE__*/React.createElement("div", {\n      style: {\n        fontSize: 12.5,\n        color: TEXT_MUTED\n      }\n    }, "Total ", /*#__PURE__*/React.createElement("strong", {\n      style: {\n        color: TEXT\n      }\n    }, tot), " \\xB7 rata-rata ", /*#__PURE__*/React.createElement("strong", {\n      style: {\n        color: TEXT\n      }\n    }, (tot / list.length).toFixed(1)), " dari ", list.length, " mapel"));\n  })(), /*#__PURE__*/React.createElement(SectionLabel, {\n    text: "5 mapel kelulusan"\n  }), CORE_SUBJECTS.map(subj => {\n    const val = latestExam(student, subj);\n    const st = statusOf(val);\n    return /*#__PURE__*/React.createElement("div", {\n      key: subj,\n      style: {\n        marginBottom: 10\n      }\n    }, /*#__PURE__*/React.createElement("div", {\n      style: {\n        display: "flex",\n        justifyContent: "space-between",\n        fontSize: 13,\n        marginBottom: 4\n      }\n    }, /*#__PURE__*/React.createElement("span", null, subj), /*#__PURE__*/React.createElement("span", {\n      style: {\n        color: statusColors(st).fg\n      }\n    }, val !== null ? val : "belum ada")), /*#__PURE__*/React.createElement(ProgressBar, {\n      pct: val !== null ? val : 0,\n      color: statusColors(st).fg,\n      height: 6\n    }));\n  }), /*#__PURE__*/React.createElement(SectionLabel, {\n    text: "Riwayat ujian bulanan"\n  }), student.examScores.slice().reverse().map(e => /*#__PURE__*/React.createElement(LogRow, {\n    key: e.id,\n    onDelete: () => onDeleteEntry(id, "examScores", e.id)\n  }, e.subject, " \\xB7 ", e.month, " \\xB7 nilai ", e.value)), !student.examScores.length && /*#__PURE__*/React.createElement(EmptyNote, {\n    text: "Belum ada ujian bulanan."\n  }), /*#__PURE__*/React.createElement(SectionLabel, {\n    text: "Riwayat nilai akademik"\n  }), student.regularScores.slice().reverse().map(e => /*#__PURE__*/React.createElement(LogRow, {\n    key: e.id,\n    onDelete: () => onDeleteEntry(id, "regularScores", e.id)\n  }, e.subject, " \\xB7 ", e.value, " \\xB7 ", e.date)), !student.regularScores.length && /*#__PURE__*/React.createElement(EmptyNote, {\n    text: "Belum ada nilai."\n  }), /*#__PURE__*/React.createElement(SectionLabel, {\n    text: "Belajar malam"\n  }), /*#__PURE__*/React.createElement(AddForm, {\n    onSubmit: () => {\n      if (!nsNote.trim()) return;\n      onAddEntry(id, "nightStudy", {\n        date: today(),\n        note: nsNote,\n        status: nsStatus\n      });\n      setNsNote("");\n    }\n  }, /*#__PURE__*/React.createElement(Field, {\n    label: "Catatan"\n  }, /*#__PURE__*/React.createElement("input", {\n    style: inputStyle,\n    value: nsNote,\n    onChange: e => setNsNote(e.target.value),\n    placeholder: "mis. Latihan Imla 20 menit"\n  })), /*#__PURE__*/React.createElement(Field, {\n    label: "Status"\n  }, /*#__PURE__*/React.createElement("select", {\n    style: inputStyle,\n    value: nsStatus,\n    onChange: e => setNsStatus(e.target.value)\n  }, /*#__PURE__*/React.createElement("option", null, "Belum"), /*#__PURE__*/React.createElement("option", null, "Sedang"), /*#__PURE__*/React.createElement("option", null, "Selesai")))), student.nightStudy.slice().reverse().map(e => /*#__PURE__*/React.createElement(LogRow, {\n    key: e.id,\n    onDelete: () => onDeleteEntry(id, "nightStudy", e.id)\n  }, e.note, " \\xB7 ", e.status, " \\xB7 ", e.date)), !student.nightStudy.length && /*#__PURE__*/React.createElement(EmptyNote, {\n    text: "Belum ada catatan."\n  }), /*#__PURE__*/React.createElement(SectionLabel, {\n    text: "Ibadah"\n  }), /*#__PURE__*/React.createElement(AddForm, {\n    onSubmit: () => {\n      if (!ibValue) return;\n      onAddEntry(id, "ibadah", {\n        date: today(),\n        value: Number(ibValue)\n      });\n      setIbValue("");\n    }\n  }, /*#__PURE__*/React.createElement(Field, {\n    label: "Nilai"\n  }, /*#__PURE__*/React.createElement("select", {\n    style: inputStyle,\n    value: ibValue,\n    onChange: e => setIbValue(e.target.value)\n  }, /*#__PURE__*/React.createElement("option", {\n    value: ""\n  }, "-"), EXAM_VALUES.map(v => /*#__PURE__*/React.createElement("option", {\n    key: v,\n    value: v\n  }, v))))), student.ibadah.slice().reverse().map(e => /*#__PURE__*/React.createElement(LogRow, {\n    key: e.id,\n    onDelete: () => onDeleteEntry(id, "ibadah", e.id)\n  }, "Nilai ", e.value, " \\xB7 ", e.date)), !student.ibadah.length && /*#__PURE__*/React.createElement(EmptyNote, {\n    text: "Belum ada nilai ibadah."\n  }), /*#__PURE__*/React.createElement(SectionLabel, {\n    text: "Izin piket rayon"\n  }), /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 13,\n      marginBottom: 8\n    }\n  }, "Total izin: ", /*#__PURE__*/React.createElement("strong", {\n    style: {\n      color: student.izinPiket.length > 3 ? RED : TEXT\n    }\n  }, student.izinPiket.length, "\\xD7"), " semester ini"), /*#__PURE__*/React.createElement(AddForm, {\n    onSubmit: () => {\n      onAddEntry(id, "izinPiket", {\n        date: today(),\n        keterangan: ipKeterangan || "Piket rayon"\n      });\n      setIpKeterangan("");\n    }\n  }, /*#__PURE__*/React.createElement(Field, {\n    label: "Keterangan"\n  }, /*#__PURE__*/React.createElement("input", {\n    style: inputStyle,\n    value: ipKeterangan,\n    onChange: e => setIpKeterangan(e.target.value),\n    placeholder: "mis. piket kamar mandi"\n  }))), student.izinPiket.slice().reverse().map(e => /*#__PURE__*/React.createElement(LogRow, {\n    key: e.id,\n    onDelete: () => onDeleteEntry(id, "izinPiket", e.id)\n  }, e.keterangan, " \\xB7 ", e.date)), !student.izinPiket.length && /*#__PURE__*/React.createElement(EmptyNote, {\n    text: "Belum ada izin piket rayon."\n  }), /*#__PURE__*/React.createElement(SectionLabel, {\n    text: "Akhlak"\n  }), /*#__PURE__*/React.createElement(AddForm, {\n    onSubmit: () => {\n      if (!akNote.trim()) return;\n      onAddEntry(id, "akhlak", {\n        date: today(),\n        note: akNote,\n        status: akStatus\n      });\n      setAkNote("");\n    }\n  }, /*#__PURE__*/React.createElement(Field, {\n    label: "Catatan"\n  }, /*#__PURE__*/React.createElement("input", {\n    style: inputStyle,\n    value: akNote,\n    onChange: e => setAkNote(e.target.value),\n    placeholder: "mis. Adab kepada guru"\n  })), /*#__PURE__*/React.createElement(Field, {\n    label: "Status"\n  }, /*#__PURE__*/React.createElement("select", {\n    style: inputStyle,\n    value: akStatus,\n    onChange: e => setAkStatus(e.target.value)\n  }, /*#__PURE__*/React.createElement("option", null, "Baik"), /*#__PURE__*/React.createElement("option", null, "Perlu pembinaan"), /*#__PURE__*/React.createElement("option", null, "Perlu perhatian khusus")))), student.akhlak.slice().reverse().map(e => /*#__PURE__*/React.createElement(LogRow, {\n    key: e.id,\n    onDelete: () => onDeleteEntry(id, "akhlak", e.id)\n  }, e.note, " \\xB7 ", e.status, " \\xB7 ", e.date)), !student.akhlak.length && /*#__PURE__*/React.createElement(EmptyNote, {\n    text: "Belum ada catatan."\n  }), /*#__PURE__*/React.createElement(SectionLabel, {\n    text: "Tingkah laku"\n  }), /*#__PURE__*/React.createElement(AddForm, {\n    onSubmit: () => {\n      if (!tlNote.trim()) return;\n      onAddEntry(id, "tingkahLaku", {\n        date: today(),\n        note: tlNote,\n        status: tlStatus\n      });\n      setTlNote("");\n    }\n  }, /*#__PURE__*/React.createElement(Field, {\n    label: "Catatan"\n  }, /*#__PURE__*/React.createElement("input", {\n    style: inputStyle,\n    value: tlNote,\n    onChange: e => setTlNote(e.target.value),\n    placeholder: "mis. Terlambat masuk kelas"\n  })), /*#__PURE__*/React.createElement(Field, {\n    label: "Status"\n  }, /*#__PURE__*/React.createElement("select", {\n    style: inputStyle,\n    value: tlStatus,\n    onChange: e => setTlStatus(e.target.value)\n  }, /*#__PURE__*/React.createElement("option", null, "Baik"), /*#__PURE__*/React.createElement("option", null, "Perlu perhatian"), /*#__PURE__*/React.createElement("option", null, "Perlu pembinaan")))), student.tingkahLaku.slice().reverse().map(e => /*#__PURE__*/React.createElement(LogRow, {\n    key: e.id,\n    onDelete: () => onDeleteEntry(id, "tingkahLaku", e.id)\n  }, e.note, " \\xB7 ", e.status, " \\xB7 ", e.date)), !student.tingkahLaku.length && /*#__PURE__*/React.createElement(EmptyNote, {\n    text: "Belum ada catatan."\n  }), /*#__PURE__*/React.createElement(SectionLabel, {\n    text: "Kebersihan"\n  }), /*#__PURE__*/React.createElement(AddForm, {\n    onSubmit: () => {\n      if (!kbWeek.trim()) return;\n      onAddEntry(id, "kebersihan", {\n        week: kbWeek,\n        personal: Number(kbPersonal) || 0,\n        kamar: Number(kbKamar) || 0,\n        kelas: Number(kbKelas) || 0,\n        barang: Number(kbBarang) || 0\n      });\n      setKbWeek("");\n      setKbPersonal("");\n      setKbKamar("");\n      setKbKelas("");\n      setKbBarang("");\n    }\n  }, /*#__PURE__*/React.createElement(Field, {\n    label: "Minggu"\n  }, /*#__PURE__*/React.createElement("input", {\n    style: inputStyle,\n    value: kbWeek,\n    onChange: e => setKbWeek(e.target.value),\n    placeholder: "Minggu 3"\n  })), /*#__PURE__*/React.createElement(Field, {\n    label: "Personal"\n  }, /*#__PURE__*/React.createElement("input", {\n    type: "number",\n    style: inputStyle,\n    value: kbPersonal,\n    onChange: e => setKbPersonal(e.target.value)\n  })), /*#__PURE__*/React.createElement(Field, {\n    label: "Kamar"\n  }, /*#__PURE__*/React.createElement("input", {\n    type: "number",\n    style: inputStyle,\n    value: kbKamar,\n    onChange: e => setKbKamar(e.target.value)\n  })), /*#__PURE__*/React.createElement(Field, {\n    label: "Kelas"\n  }, /*#__PURE__*/React.createElement("input", {\n    type: "number",\n    style: inputStyle,\n    value: kbKelas,\n    onChange: e => setKbKelas(e.target.value)\n  })), /*#__PURE__*/React.createElement(Field, {\n    label: "Barang"\n  }, /*#__PURE__*/React.createElement("input", {\n    type: "number",\n    style: inputStyle,\n    value: kbBarang,\n    onChange: e => setKbBarang(e.target.value)\n  }))), student.kebersihan.slice().reverse().map(e => /*#__PURE__*/React.createElement(LogRow, {\n    key: e.id,\n    onDelete: () => onDeleteEntry(id, "kebersihan", e.id)\n  }, e.week, " \\xB7 personal ", e.personal, ", kamar ", e.kamar, ", kelas ", e.kelas, ", barang ", e.barang)), !student.kebersihan.length && /*#__PURE__*/React.createElement(EmptyNote, {\n    text: "Belum ada catatan."\n  }), /*#__PURE__*/React.createElement(SectionLabel, {\n    text: "Target dan intervensi"\n  }), /*#__PURE__*/React.createElement(AddForm, {\n    onSubmit: () => {\n      if (!tgArea.trim()) return;\n      onAddEntry(id, "targets", {\n        area: tgArea,\n        target: tgTarget,\n        deadline: tgDeadline,\n        status: tgStatus\n      });\n      setTgArea("");\n      setTgTarget("");\n      setTgDeadline("");\n      setTgStatus("Belum");\n    }\n  }, /*#__PURE__*/React.createElement(Field, {\n    label: "Area/masalah"\n  }, /*#__PURE__*/React.createElement("input", {\n    style: inputStyle,\n    value: tgArea,\n    onChange: e => setTgArea(e.target.value),\n    placeholder: "mis. Berhitung"\n  })), /*#__PURE__*/React.createElement(Field, {\n    label: "Target"\n  }, /*#__PURE__*/React.createElement("input", {\n    style: inputStyle,\n    value: tgTarget,\n    onChange: e => setTgTarget(e.target.value),\n    placeholder: "mis. 75"\n  })), /*#__PURE__*/React.createElement(Field, {\n    label: "Deadline"\n  }, /*#__PURE__*/React.createElement("input", {\n    style: inputStyle,\n    value: tgDeadline,\n    onChange: e => setTgDeadline(e.target.value),\n    placeholder: "2 minggu"\n  })), /*#__PURE__*/React.createElement(Field, {\n    label: "Status"\n  }, /*#__PURE__*/React.createElement("select", {\n    style: inputStyle,\n    value: tgStatus,\n    onChange: e => setTgStatus(e.target.value)\n  }, /*#__PURE__*/React.createElement("option", null, "Belum"), /*#__PURE__*/React.createElement("option", null, "Proses"), /*#__PURE__*/React.createElement("option", null, "Tercapai")))), student.targets.slice().reverse().map(e => /*#__PURE__*/React.createElement(LogRow, {\n    key: e.id,\n    onDelete: () => onDeleteEntry(id, "targets", e.id)\n  }, e.area, " \\u2192 ", e.target, " \\xB7 ", e.deadline, " \\xB7 ", e.status)), !student.targets.length && /*#__PURE__*/React.createElement(EmptyNote, {\n    text: "Belum ada target."\n  })));\n}\nfunction SectionLabel({\n  text\n}) {\n  return /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      margin: "20px 0 8px",\n      textTransform: "uppercase",\n      letterSpacing: 0.3\n    }\n  }, text);\n}\nfunction EmptyNote({\n  text\n}) {\n  return /*#__PURE__*/React.createElement("div", {\n    style: {\n      fontSize: 12,\n      color: TEXT_MUTED,\n      padding: "8px 0"\n    }\n  }, text);\n}\nfunction AddForm({\n  children,\n  onSubmit\n}) {\n  return /*#__PURE__*/React.createElement("div", {\n    style: {\n      display: "flex",\n      flexWrap: "wrap",\n      gap: 8,\n      alignItems: "flex-end",\n      background: PAPER,\n      padding: 10,\n      borderRadius: 8,\n      marginBottom: 4\n    }\n  }, children, /*#__PURE__*/React.createElement("button", {\n    onClick: onSubmit,\n    style: {\n      background: INK,\n      color: "#fff",\n      border: "none",\n      borderRadius: 6,\n      padding: "7px 12px",\n      cursor: "pointer",\n      fontSize: 12,\n      display: "flex",\n      alignItems: "center",\n      gap: 4\n    }\n  }, /*#__PURE__*/React.createElement(Plus, {\n    size: 13\n  }), " Tambah"));\n}\nconst __root = ReactDOM.createRoot(document.getElementById("root"));\n__root.render(/*#__PURE__*/React.createElement(App, null));';
var STORE_NAME = "b15-data";
var KEY_RE = /^(students|meta)\/[A-Za-z0-9_.~:@+-]{1,80}$/;
var json = (obj, status = 200) => new Response(JSON.stringify(obj), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});
async function digest(text) {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)));
}
async function sameCode(given, expected) {
  const [a, b] = await Promise.all([digest(given), digest(expected)]);
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}
var db_src_default = async (req) => {
  if (req.method !== "POST") return json({ error: "method" }, 405);
  const expected = Netlify.env.get("ACCESS_CODE");
  if (!expected) return json({ error: "ACCESS_CODE belum diatur" }, 503);
  const given = req.headers.get("x-access-code") || "";
  if (!await sameCode(given, expected)) {
    await new Promise((r) => setTimeout(r, 500));
    return json({ error: "unauthorized" }, 401);
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "bad json" }, 400);
  }
  const op = body && body.op;
  if (op === "ping") return json({ ok: true });
  if (op === "app") {
    return new Response(APP_JS, {
      headers: { "content-type": "text/javascript; charset=utf-8", "cache-control": "no-store" }
    });
  }
  const store = getStore({ name: STORE_NAME, consistency: "strong" });
  if (op === "list") {
    const { blobs } = await store.list();
    return json({ items: blobs.map((b) => ({ key: b.key, etag: b.etag })) });
  }
  if (op === "getMany") {
    const keys = Array.isArray(body.keys) ? body.keys.slice(0, 60) : [];
    if (!keys.every((k) => typeof k === "string" && KEY_RE.test(k))) return json({ error: "bad key" }, 400);
    const results = await Promise.all(
      keys.map(async (key) => {
        const e = await store.getWithMetadata(key, { type: "json" });
        return e ? { key, data: e.data, etag: e.etag } : { key, data: null, etag: null };
      })
    );
    return json({ results });
  }
  const path = body && body.path;
  if (typeof path !== "string" || !KEY_RE.test(path)) return json({ error: "bad path" }, 400);
  if (op === "set") {
    if (!body.data || typeof body.data !== "object" || Array.isArray(body.data)) return json({ error: "bad data" }, 400);
    await store.setJSON(path, body.data);
    return json({ ok: true });
  }
  if (op === "update") {
    if (!body.data || typeof body.data !== "object" || Array.isArray(body.data)) return json({ error: "bad data" }, 400);
    const cur = await store.get(path, { type: "json" });
    if (cur === null) return json({ error: "not-found" }, 404);
    await store.setJSON(path, { ...cur, ...body.data });
    return json({ ok: true });
  }
  if (op === "delete") {
    await store.delete(path);
    return json({ ok: true });
  }
  return json({ error: "unknown op" }, 400);
};
var config = { path: "/api/db", method: "POST" };
export {
  config,
  db_src_default as default
};
